# FleshMarket — Patch G: Quest Removal + XP Overhaul

## Summary
Removed the daily quest system entirely. Replaced with pure activity-based XP
that rewards real trading skill and market participation.

## Removed
- `QUEST_POOL` — 10 daily quest templates
- `playerQuests` in-memory Map (was lost on every server restart)
- `getTodayKey()`, `getPlayerQuests()`, `updateQuestProgress()` functions
- `📋 Quests` tab from client UI
- Quest CSS, `renderQuests()`, `quest_complete` / `quests` WS handlers
- All `updateQuestProgress()` call sites

## New XP Model

| Activity | XP |
|---|---|
| Buy trade | `max(3, min(50, tradeValue ÷ 20))` — scales with size |
| Sell trade | 3 XP base + up to 100 XP profit bonus (`profit ÷ 10`, capped) |
| Short entry | 5 XP |
| Limit fill | 3 XP (unchanged) |
| IPO participation | 15 XP (up from 5) |
| Transfer | 2 XP (unchanged) |
| Dividend received | 3 XP (unchanged) |

XP is fully persisted in SQLite — survives server restarts.
Levels and titles remain unchanged (999-level curve, Store unlocks).

## New UI
- **XP progress bar** added below positions list in the left panel
- Shows: current level, title (if equipped), XP progress within level
- Updates on every portfolio tick — smooth CSS transition

---

## Patch G.1 — Casino Sync Bugfix Pass

### Bug Fixes

**[HIGH] Casino cash desyncs on Blackjack, Horse Races, Chess** (Bug #1)
- Root cause: `_syncCasinoCash()` was defined inside the Roulette IIFE only. Blackjack, Horse Races, and Chess called it from their own isolated IIFEs — silently throwing `ReferenceError` every time.
- Result: Winnings/losses in those three games updated `ME.cash` client-side but never reached the server. Refreshing the page would restore the pre-session balance.
- Fix: Replaced all 4 `_syncCasinoCash()` call sites with inline `ws.send({type:'casino', sync:...})` — no scope dependency.

**[LOW] `ws.onmessage` assignment was dead code** (Bug #2)
- The `ws` proxy object only supports `.send()` and `.addEventListener()`. Assigning `.onmessage` added an unreachable property.
- Fix: Changed to `ws.addEventListener('message', ...)` with proper `ev.data` / `ev.detail.data` fallback for the custom proxy event format.

**[COSMETIC] Orphaned `chessTimeControl` listener IIFE** (Bug #3)
- A small IIFE attempted to attach a `change` listener to `#chessTimeControl` before the Chess IIFE had injected the element into the DOM. `tcSel` was always null — the block exited silently.
- The Chess IIFE already registers this listener correctly.
- Fix: Removed the orphaned IIFE. Comment retained for clarity.
