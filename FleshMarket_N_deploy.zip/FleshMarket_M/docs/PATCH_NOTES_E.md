# FleshMarket v3.0 — Patch E: SQLite Player Persistence

## What changed

### Server
- **New: `server/db.js`** — Full SQLite database layer using `better-sqlite3`
  - WAL journal mode (safe concurrent reads + fast writes)
  - Player accounts: id, name, hashed password, cash, XP, level, title
  - Holdings and cost-basis stored in normalized tables
  - Net worth history table (up to 1000 snapshots per player) — powers the P&L chart
  - Market state (prices, OHLC, headlines) persisted in DB instead of `state.json`
- **Updated: `server/server.js`** — Rewired to use DB layer
  - All game logic (market sim, NPC, orders, casino sync) preserved exactly
  - Player wallets, holdings, and XP survive server restarts
  - Dev credentials moved OUT of source code (see `.env.example`)
  - Cleaner REST API: `/api/register`, `/api/login`, `/api/whoami`, `/api/rename`, `/api/pnl/:token`
- **New: `server/.env.example`** — Copy to `.env` to configure port, dev accounts, etc.

### Client
- **New: `client/assets/fm-auth.js`** — Replaces `account-auth.js` with server-backed register/login
  - Creates accounts against `/api/register` (password hashed with PBKDF2 + SHA-512 server-side)
  - Logs in via `/api/login`, stores token in `localStorage`
  - Token sent as `?token=<id>` in WebSocket URL — server hydrates full persistent player on connect
  - Live name-availability check while typing
  - Auto-verifies stored token on page load, re-shows login if stale
  - "New account" / "Log In" toggle in the modal
- **Removed: `account-auth.js`, `account-persist.js`** — Superseded by server-side auth

## New dependencies
```
better-sqlite3  ^9.6.0   (fast sync SQLite — no callback hell)
dotenv          ^16.4.5  (load .env config)
```

## Setup (first time)
```bash
cd server
cp .env.example .env
# Edit .env — set DEV_ACCOUNTS=YourName:YourPassword if you want a dev badge
npm install
npm start
```
The database file (`fleshmarket.db`) is created automatically on first run.

## Migrating from v2
Old `players.json` and `state.json` are no longer used. Players will need to create
new accounts. Market state will reset once, then persist going forward.

## Security notes
- Passwords are hashed with PBKDF2 (100,000 iterations, SHA-512, 64-byte output)
- Constant-time comparison used for password verification
- Dev account credentials are never in source code — always `.env` only
- `.gitignore` prevents committing `.env` and the database file
