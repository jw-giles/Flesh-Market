# FleshMarket — Patch F: Casino Sanity Pass

## Bug Fixes (`client/index.html`)

### Chess — Timeout status message bug
- `endGame()` had `stopClock()` and time-check blocks duplicated, causing
  `result` to be mutated before the status message block ran
- Result: timeout losses showed "Checkmated." instead of "You ran out of time."
- Fix: removed duplicate block, track `timedResult` separately so correct
  message is shown for each outcome (timeout win/loss, checkmate, surrender, draw)

### Horse Races — Broken `getBalance` fallback regex
- Regex `/[^\\d.-]/g` in the ME.cash fallback path used `\\d` (escaped backslash + literal d)
  instead of `\d` (digit class), stripping digits from the cash string instead of currency symbols
- Fix: corrected to `/[^\d.-]/g`

### All Casino Games — Junk `marketAPI.sell(sym, qty)` injected into balance functions
- 9 dead-code calls to `window.marketAPI.sell(sym, qty)` were embedded inside
  `setBalance()` and settle handlers across Roulette, Blackjack, Horse Races, and Chess
- `sym` and `qty` were always `undefined`; calls were silently swallowed by try-catch
  but fired on every single balance update, causing console noise
- All 9 instances removed cleanly

## Games confirmed working
- Roulette: payouts, spin animation, bet escrow
- Blackjack: 6-deck shoe, ace logic, 3:2 blackjack, double-down, dealer stands soft 17
- Poker: hand evaluator (incl. wheel straight A-low), pot accounting, AI strategy, blind levels
- Horse Races: canvas animation, 5x payout, planned-winner guarantee
- Chess: move generator, alpha-beta AI, clock increment, ELO tiers, wager model
