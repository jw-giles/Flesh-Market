# FleshMarket v5.0 — "Full Flesh" Patch Notes

---

## Server Changes (`server/server.js`)

### Limit Orders
- Players can place buy or sell limit orders with `limit_order` WS message
- Buy limits **reserve cash upfront** (refund difference on fill)
- Orders auto-fill every tick when market price crosses limit
- 24-hour expiry with automatic cash refund
- Cancel anytime with `cancel_limit` message
- `orders` broadcast sent on connect, after place/cancel/fill

### Short Selling
- Selling more shares than you own enters a **negative position**
- Shorts charged a **0.1% borrow fee** every 30 minutes on position value
- Server timer: `BORROW_INTERVAL_MS = 30min`
- Quest: "Open a short position" tracks short entries
- Borrow fee notification: `borrow_fee` WS message to affected player

### Earnings Events (`EARNINGS_INTERVAL_MS = 8min`)
- Random company picked every 8 minutes
- 45% chance beat, 55% miss
- **6–20% price swing** applied immediately
- Global headline broadcast + targeted `earnings_alert` to all holders of that stock
- Price change is permanent (applied to `lnP`)

### IPO Events (`IPO_INTERVAL_MS = 90min`)
- Random eligible company (price > ₥5) gets a 90-second IPO window
- **15–35% discount** from current market price
- Max **100 shares per player**, one participation per IPO
- `ipo` broadcast to all connected clients (including reconnect catch-up)
- `ipo_expired` broadcast after window closes
- `ipo_apply` WS handler for players to buy in

### Dividends (`DIVIDEND_INTERVAL_MS = 2h`)
- Paid to players with **long positions in dividend sectors**
- Dividend sectors: Finance (0), Insurance (2), Energy (4), Tech (6)
- Rate: **0.6%** of position value per 2-hour cycle
- `dividend` WS message with amount sent to each player

### Trade Feed
- Every market order fill, limit fill, and IPO buy broadcasts a `trade_feed` message
- Includes: side, symbol, qty, price, isLimit, isIPO flags
- Anonymized — no player names

### Daily Quests
- 3 random quests assigned per player per day (resets at midnight)
- Quest pool of 10 types: trade, buy, profit, limit, short, transfer, hold, ipo
- Progress tracked server-side via `updateQuestProgress()`
- `quests` array broadcast on connect, after each progress update
- `quest_complete` broadcast with XP reward when finished
- XP bonuses applied immediately to player account

### Heatmap Data
- Every `tick` broadcast now includes `pct` (% change from daily open) and `sector` per ticker
- `prevClose` map resets daily at midnight
- FLSH special company excluded from normal simulation

### Portfolio Snapshot (v5.0)
- `snapshotPortfolio()` now includes:
  - `isShort` flag per position
  - `sectorName` per position
  - `shortExposure` total
  - `sectorBreakdown` map: `{ sectorName -> totalValue }`
- Allows negative qty positions (short selling)

---

## Client Changes (`client/index.html`)

### New Tabs
- **🔥 Heat** tab — full market heatmap grid
- **📋 Quests** tab — daily quest progress cards

### Market Heatmap
- Grid of all tickers color-coded green/red by % change vs daily open
- Color intensity scales with magnitude (saturates at ±5%)
- Click any cell to load that stock's chart

### Limit Order Panel
- Below buy/sell row in Market tab
- Side dropdown (BUY/SELL), symbol, qty, limit price inputs
- Lists open orders with cancel buttons
- Reserved cash shown in portfolio immediately

### Trade Feed
- Live scrolling feed of anonymized trade events
- Injected below News in left panel
- IPO buys shown in gold, limit fills marked `[L]`

### Quests Panel
- Progress bars for each daily quest
- XP reward shown per quest
- Completed quests grayed out with ✅

### Sector Breakdown
- Added to P&L tab below equity chart
- Horizontal bar chart of portfolio value by sector

### IPO Banner
- Fixed overlay when an IPO is active
- Shows symbol, company name, market price, discounted price, % discount
- Live countdown timer
- Qty input + Buy button
- Auto-dismisses on expiry

### Earnings / Dividend Toasts
- Earnings alerts show as colored toast notification (green = beat, red = miss)
- Dividend received shows toast + chat system message
- Short borrow fee shows orange toast

### Sound Effects (Web Audio API)
- Toggle button fixed to bottom-right
- Off by default
- Buy: ascending tone
- Sell: descending tone
- Limit fill: triangle wave ping
- Quest complete: 3-note fanfare

---

## Config Constants Added
```
EARNINGS_INTERVAL_MS  = 8min
IPO_INTERVAL_MS       = 90min
IPO_WINDOW_MS         = 90s
DIVIDEND_INTERVAL_MS  = 2h
BORROW_INTERVAL_MS    = 30min
BORROW_RATE           = 0.001  (0.1%/30min)
DIVIDEND_RATE         = 0.006  (0.6%/2h)
DIVIDEND_SECTORS      = { Finance, Insurance, Energy, Tech }
```
