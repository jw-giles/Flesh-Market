# Flesh Market — Local Bundle

Node.js server (WebSocket + Express) + static client. Run it locally on any OS.

**Requires Node.js v22.5 or newer** — the server uses the built-in `node:sqlite` module
added in Node 22.5. Older versions will not work.

---

## Quick Start

### Linux / macOS

```bash
cd server
chmod +x start_server.sh
./start_server.sh
```

The script handles dependencies, port conflicts, and opens your browser automatically.

### Windows

Double-click `server/start_server.bat` — or from a terminal:

```
cd server
start_server.bat
```

---

## Installing Node.js v22.5+

### Ubuntu / Debian (recommended method)
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node --version   # must show v22.5 or higher
```

### Arch Linux
```bash
sudo pacman -S nodejs npm
```

### Fedora / RHEL / CentOS
```bash
sudo dnf install nodejs
```

### macOS
```bash
brew install node
```

### Any platform — nvm (easiest if you manage multiple projects)
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
# restart terminal, then:
nvm install 22
nvm use 22
node --version   # should show v22.x.x
```

---

## Manual Start (without the launch script)

```bash
cd server
npm install
node --experimental-sqlite server.js
```

Open **http://localhost:7777**

---

## Configuration

On first run, `server/.env` is created automatically from `.env.example`.
Edit it to configure:

| Variable              | Default  | Description                                  |
|-----------------------|----------|----------------------------------------------|
| PORT                  | 7777     | Port the server listens on                   |
| TRADE_TAX_BPS         | 25       | Transfer tax in basis points (25 = 0.25%)    |
| DEV_ACCOUNTS          | (empty)  | Comma-separated dev account names            |
| PATREON_WEBHOOK_SECRET| (empty)  | Leave blank for local dev                    |

Custom port example:
```bash
PORT=8080 ./start_server.sh
```

---

## Basic Usage

1. Open http://localhost:7777
2. Enter a username and press Join
3. Click a company in the left panel to load its chart
4. Buy / Sell to trade; use Limit Orders panel for set-price orders
5. Transfer tab to wire cash between players (2% tax burned)
6. Heat tab — full market heatmap, click any tile to switch charts
7. Quests tab — daily quest progress and XP rewards
8. P&L tab — net worth chart and sector breakdown

---

## Optional Tweaks (server/server.js)

| Constant               | What it does                              |
|------------------------|-------------------------------------------|
| TICK_MS                | Market tick speed (lower = faster)        |
| NEWS_MS                | Headline cadence                          |
| EARNINGS_INTERVAL_MS   | How often earnings events fire (8 min)    |
| IPO_INTERVAL_MS        | How often IPO windows open (90 min)       |
| DIVIDEND_INTERVAL_MS   | Dividend payout cycle (2 hr)              |
| MAX_SHARES_PER_ORDER   | Max shares per single order               |

---

## Troubleshooting

**node:sqlite error / DatabaseSync is not a constructor**
Your Node.js is too old. Run `node --version` — you need v22.5+.
Fix: `nvm install 22 && nvm use 22`

**Blank page / no market data**
Make sure the server is running and you're at http://localhost:7777
(not opening the HTML file directly from your filesystem).

**Port already in use**
The launch script handles this automatically.
Manual fix: `PORT=8080 node --experimental-sqlite server.js`

**permission denied on start_server.sh**
Run: `chmod +x server/start_server.sh`

**Browser does not open automatically on Linux**
Install xdg-utils: `sudo apt install xdg-utils`
Or just open http://localhost:7777 manually.

**npm install fails with EACCES**
Do not use sudo npm install. Fix npm permissions instead:
`mkdir -p ~/.npm-global && npm config set prefix '~/.npm-global'`

---

## Persistence

Player accounts, holdings, and market state are stored in `server/fleshmarket.db` (SQLite).
Data survives server restarts. Delete the .db file to wipe and start fresh.
