/**
 * db.js — FleshMarket SQLite persistence layer v2
 * Uses node:sqlite (built into Node.js 22.5+/24). Zero native deps.
 *
 * Patreon tiers:
 *   0 = Free
 *   1 = Premium      ($5/mo)  — +100 every 30min, name badge
 *   2 = Merchants Guild ($25/mo) — +500 every 30min, custom chat, hedge fund
 *   3 = CEO          ($100/mo) — +2500 every 30min, no transfer fees, all perks
 */

import { DatabaseSync } from 'node:sqlite';
import { pbkdf2Sync, randomBytes } from 'crypto';
import path from 'path';
import url  from 'url';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const DB_PATH   = process.env.DB_PATH || path.join(__dirname, 'fleshmarket.db');

let db;
const S = {};

function stmt(sql) {
  if (!S[sql]) S[sql] = db.prepare(sql);
  return S[sql];
}

function transaction(fn) {
  return function(...args) {
    db.exec('BEGIN');
    try { const r = fn(...args); db.exec('COMMIT'); return r; }
    catch(e) { try { db.exec('ROLLBACK'); } catch(_){} throw e; }
  };
}

// ─── Tier config (single source of truth) ─────────────────────────────────────

export const TIERS = {
  0: { name: 'Free',            badge: null,       chatColor: null,      incomeEvery30: 25,        transferFee: true  },
  1: { name: 'Premium',         badge: '\u2605',   chatColor: null,      incomeEvery30: 100,       transferFee: true  },
  2: { name: 'Merchants Guild', badge: '\u2696',   chatColor: '#4ecdc4', incomeEvery30: 500,       transferFee: true  },
  3: { name: 'CEO',             badge: '\u265b',   chatColor: '#ffd700', incomeEvery30: 2500,      transferFee: false },
};
// Dev passive income — applied separately in creditPassiveIncome
export const DEV_INCOME_EVERY30 = 10_000_000; // ₥10M per reset
export const CEO_MAX = 10;

// ─── Init ─────────────────────────────────────────────────────────────────────

export function initDB() {
  db = new DatabaseSync(DB_PATH);
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA foreign_keys = ON');
  db.exec('PRAGMA synchronous = NORMAL');
  db.exec(`
    CREATE TABLE IF NOT EXISTS players (
      id                TEXT PRIMARY KEY,
      name              TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash     TEXT NOT NULL,
      password_salt     TEXT NOT NULL,
      cash              REAL    NOT NULL DEFAULT 1000,
      xp                INTEGER NOT NULL DEFAULT 0,
      level             INTEGER NOT NULL DEFAULT 1,
      title             TEXT,
      badges            TEXT    NOT NULL DEFAULT '[]',
      patreon_tier      INTEGER NOT NULL DEFAULT 0,
      patreon_email     TEXT,
      patreon_member_id TEXT,
      patreon_expires_at INTEGER,
      created_at        INTEGER NOT NULL,
      updated_at        INTEGER NOT NULL,
      last_seen         INTEGER,
      is_prime          INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS holdings (
      player_id TEXT    NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      symbol    TEXT    NOT NULL,
      qty       INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (player_id, symbol)
    );
    CREATE TABLE IF NOT EXISTS basis (
      player_id TEXT    NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      symbol    TEXT    NOT NULL,
      basis_c   INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (player_id, symbol)
    );
    CREATE TABLE IF NOT EXISTS net_worth_history (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      net_worth REAL NOT NULL,
      cash      REAL NOT NULL,
      equity    REAL NOT NULL,
      ts        INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS market_state (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_nwh_player_ts ON net_worth_history(player_id, ts);
    CREATE INDEX IF NOT EXISTS idx_players_patreon_email ON players(patreon_email);
    CREATE INDEX IF NOT EXISTS idx_players_patreon_member ON players(patreon_member_id);
    CREATE TABLE IF NOT EXISTS colony_state (
      id                  TEXT PRIMARY KEY,
      faction             TEXT NOT NULL DEFAULT 'coalition',
      control_coalition   INTEGER NOT NULL DEFAULT 0,
      control_syndicate   INTEGER NOT NULL DEFAULT 0,
      control_void        INTEGER NOT NULL DEFAULT 0,
      tension             INTEGER NOT NULL DEFAULT 0,
      contested           INTEGER NOT NULL DEFAULT 0,
      conquest_faction    TEXT,
      conquest_timer      INTEGER,
      war_chest           REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS faction_funding (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      player_id  TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      colony_id  TEXT NOT NULL,
      faction_id TEXT NOT NULL,
      amount     REAL NOT NULL,
      ts         INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_ff_colony ON faction_funding(colony_id, faction_id);
    CREATE INDEX IF NOT EXISTS idx_ff_player ON faction_funding(player_id);
  `);

  // Migration: safely add new columns if they don't exist yet (upgrade from older DB)
  const _existingCols = new Set(
    db.prepare('PRAGMA table_info(players)').all().map(r => r.name)
  );
  const _migrations = [
    ['patreon_tier',      'INTEGER NOT NULL DEFAULT 0'],
    ['patreon_email',     'TEXT'],
    ['patreon_member_id', 'TEXT'],
    ['patreon_expires_at','INTEGER'],
    ['is_dev',            'INTEGER NOT NULL DEFAULT 0'],
    ['is_admin',          'INTEGER NOT NULL DEFAULT 0'],
    ['faction',           'TEXT'],
  ];
  for (const [col, def] of _migrations) {
    if (!_existingCols.has(col)) {
      db.exec(`ALTER TABLE players ADD COLUMN ${col} ${def}`);
      console.log(`[DB] Migrated: added column ${col}`);
    }
  }

  console.log(`[DB] SQLite ready: ${DB_PATH}`);
  return db;
}

// ─── Transactions ─────────────────────────────────────────────────────────────

export let savePlayerFn;
export let recordNetWorthFn;

export function setupTransactions() {
  savePlayerFn = transaction((player) => {
    const now = Date.now();
    stmt(`UPDATE players
          SET cash=?,xp=?,level=?,title=?,patreon_tier=?,patreon_email=?,
              patreon_member_id=?,patreon_expires_at=?,updated_at=?,last_seen=?
          WHERE id=?`)
      .run(
        player.cash, player.xp, player.level, player.title||null,
        player.patreon_tier||0, player.patreon_email||null,
        player.patreon_member_id||null, player.patreon_expires_at||null,
        now, now, player.id
      );
    stmt('DELETE FROM holdings WHERE player_id=?').run(player.id);
    for (const [sym, qty] of Object.entries(player.holdings||{})) {
      if (qty>0) stmt('INSERT OR REPLACE INTO holdings VALUES(?,?,?)').run(player.id,sym,qty);
    }
    stmt('DELETE FROM basis WHERE player_id=?').run(player.id);
    for (const [sym, bc] of Object.entries(player.basisC||{})) {
      if (bc>0) stmt('INSERT OR REPLACE INTO basis VALUES(?,?,?)').run(player.id,sym,Math.floor(bc));
    }
  });

  recordNetWorthFn = transaction((playerId, net, cash, equity) => {
    stmt('INSERT INTO net_worth_history(player_id,net_worth,cash,equity,ts) VALUES(?,?,?,?,?)')
      .run(playerId, net, cash, equity, Date.now());
    stmt(`DELETE FROM net_worth_history WHERE player_id=? AND id NOT IN
          (SELECT id FROM net_worth_history WHERE player_id=? ORDER BY ts DESC LIMIT 1000)`)
      .run(playerId, playerId);
  });
}

// ─── Password ─────────────────────────────────────────────────────────────────

function hashPassword(password, salt) {
  return pbkdf2Sync(password, salt, 100_000, 64, 'sha512').toString('hex');
}
export function createPasswordHash(password) {
  const salt = randomBytes(16).toString('hex');
  return { hash: hashPassword(password, salt), salt };
}
export function verifyPassword(password, hash, salt) {
  const attempt = hashPassword(password, salt);
  const a = Buffer.from(attempt, 'hex');
  const b = Buffer.from(hash,    'hex');
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i=0;i<a.length;i++) diff |= a[i]^b[i];
  return diff === 0;
}

// ─── Player CRUD ──────────────────────────────────────────────────────────────

function hydratePlayer(row) {
  if (!row) return null;
  const holdings={}, basisC={};
  stmt('SELECT symbol,qty FROM holdings WHERE player_id=?').all(row.id)
    .forEach(h=>{ if(h.qty>0) holdings[h.symbol]=h.qty; });
  stmt('SELECT symbol,basis_c FROM basis WHERE player_id=?').all(row.id)
    .forEach(b=>{ if(b.basis_c>0) basisC[b.symbol]=b.basis_c; });
  return {
    id:row.id, name:row.name,
    password_hash:row.password_hash, password_salt:row.password_salt,
    cash:row.cash, xp:row.xp, level:row.level,
    title:row.title||null,
    badges: JSON.parse(row.badges||'[]'),
    patreon_tier: row.patreon_tier||0,
    patreon_email: row.patreon_email||null,
    patreon_member_id: row.patreon_member_id||null,
    patreon_expires_at: row.patreon_expires_at||null,
    holdings, basisC,
    createdAt:row.created_at, updatedAt:row.updated_at, lastSeen:row.last_seen,
  };
}

export function createPlayerSync(id, name, password) {
  const now = Date.now();
  const {hash,salt} = createPasswordHash(password);
  stmt(`INSERT INTO players(id,name,password_hash,password_salt,cash,xp,level,badges,patreon_tier,created_at,updated_at)
        VALUES(?,?,?,?,1000,0,1,'[]',0,?,?)`)
    .run(id,name,hash,salt,now,now);
  return getPlayer(id);
}
export function getPlayer(id) { return hydratePlayer(stmt('SELECT * FROM players WHERE id=?').get(id)); }
export function getPlayerByName(name) { return hydratePlayer(stmt('SELECT * FROM players WHERE name=? COLLATE NOCASE').get(name)); }
export function getPlayerByPatreonEmail(email) { return hydratePlayer(stmt('SELECT * FROM players WHERE patreon_email=? COLLATE NOCASE').get(email)); }
export function getPlayerByPatreonMemberId(memberId) { return hydratePlayer(stmt('SELECT * FROM players WHERE patreon_member_id=?').get(memberId)); }
export function isNameAvailable(name) {
  if (!name||!name.trim()) return false;
  return !stmt('SELECT id FROM players WHERE name=? COLLATE NOCASE').get(name.trim());
}
export function touchPlayer(id) { stmt('UPDATE players SET last_seen=? WHERE id=?').run(Date.now(),id); }
export function renamePlayer(id,newName) { stmt('UPDATE players SET name=?,updated_at=? WHERE id=?').run(newName.trim(),Date.now(),id); }
export function countCEOs() { return (stmt('SELECT COUNT(*) as n FROM players WHERE patreon_tier=3').get()||{n:0}).n; }

// ─── Patreon tier management ──────────────────────────────────────────────────

export function setPatreonTier(playerId, tier, memberId, expiresAt) {
  stmt(`UPDATE players SET patreon_tier=?,patreon_member_id=?,patreon_expires_at=?,updated_at=? WHERE id=?`)
    .run(tier, memberId||null, expiresAt||null, Date.now(), playerId);
}

export function linkPatreonEmail(playerId, email) {
  stmt('UPDATE players SET patreon_email=?,updated_at=? WHERE id=?').run(email.toLowerCase().trim(), Date.now(), playerId);
}

// Revoke expired Patreon tiers (call periodically)
export function revokeExpiredPatreon() {
  const now = Date.now();
  const expired = stmt(`SELECT id FROM players WHERE patreon_tier>0 AND patreon_expires_at IS NOT NULL AND patreon_expires_at<?`).all(now);
  for (const row of expired) {
    stmt('UPDATE players SET patreon_tier=0,patreon_member_id=null,patreon_expires_at=null,updated_at=? WHERE id=?')
      .run(now, row.id);
  }
  return expired.length;
}

// Credit passive income to all players with a tier > 0
// Guild members (tier >= 2) get +1% base income per current guild member
// Returns { count, payouts: [{id, base, bonus, total, guildMemberCount}] }
export function creditPassiveIncome() {
  const players = stmt('SELECT id,patreon_tier,is_dev FROM players').all();
  const guildMemberCount = stmt('SELECT COUNT(*) as n FROM players WHERE patreon_tier>=2 OR is_dev=1 OR is_admin=1').get().n;
  const guildBonusPct = guildMemberCount * 0.01; // 1% per guild member

  const payouts = [];
  const now = Date.now();
  for (const row of players) {
    const isDev = !!(row.is_dev);
    if (isDev) {
      // Developer accounts receive the absurd dev passive
      const total = DEV_INCOME_EVERY30;
      stmt('UPDATE players SET cash=cash+?,updated_at=? WHERE id=?').run(total, now, row.id);
      payouts.push({ id: row.id, base: total, bonus: 0, total, guildMemberCount, isDev: true });
      continue;
    }
    const tier = TIERS[row.patreon_tier ?? 0];
    if (!tier || !tier.incomeEvery30) continue;
    const base = tier.incomeEvery30;
    // Guild bonus only applies to Merchants Guild (tier 2) and CEO (tier 3)
    const bonusMult = row.patreon_tier >= 2 ? guildBonusPct : 0;
    const bonus = Math.floor(base * bonusMult);
    const total = base + bonus;
    stmt('UPDATE players SET cash=cash+?,updated_at=? WHERE id=?').run(total, now, row.id);
    payouts.push({ id: row.id, base, bonus, total, guildMemberCount });
  }
  return { count: players.length, payouts, guildMemberCount };
}

// ─── Net worth history ────────────────────────────────────────────────────────

export function getNetWorthHistory(playerId, limit=200) {
  return stmt(`SELECT net_worth,cash,equity,ts FROM net_worth_history
               WHERE player_id=? ORDER BY ts DESC LIMIT ?`)
    .all(playerId,limit).reverse();
}

// ─── Leaderboard ─────────────────────────────────────────────────────────────

export function getLeaderboard(companies, limit=20) {
  const cutoff = Date.now() - 2*60*1000;
  const players = stmt(`SELECT id,name,cash,xp,level,title,patreon_tier,is_dev,is_admin,is_prime FROM players WHERE last_seen>=? AND (is_dev=0 AND is_admin=0 OR is_prime=1)`).all(cutoff);
  return players.map(p=>{
    const holdRows = stmt('SELECT symbol,qty FROM holdings WHERE player_id=?').all(p.id);
    const equity   = holdRows.reduce((acc,h)=>{ const c=companies.find(x=>x.symbol===h.symbol); return acc+(c?c.price*h.qty:0); },0);
    return { id:p.id, name:p.name, net:p.cash+equity, xp:p.xp, level:p.level, title:p.title, patreon_tier:p.patreon_tier||0, is_dev:!!(p.is_dev||p.is_admin), is_prime:!!(p.is_prime) };
  }).sort((a,b)=>b.net-a.net).slice(0,limit);
}

// ─── Market state ─────────────────────────────────────────────────────────────

export function saveMarketState(companies, headlines) {
  const state = {
    companies: companies.map(c=>({id:c.id,name:c.name,symbol:c.symbol,price:c.price,lnP:c.lnP,sigma:c.sigma,ohlc:c.ohlc})),
    headlines: headlines.slice(-200),
    savedAt: Date.now()
  };
  stmt('INSERT OR REPLACE INTO market_state(key,value) VALUES(?,?)').run('main',JSON.stringify(state));
}
export function loadMarketState() {
  const row = stmt('SELECT value FROM market_state WHERE key=?').get('main');
  if (!row) return null;
  try { return JSON.parse(row.value); } catch { return null; }
}

// ═══════════════════════════════════════════════════════════════════════════
// HEDGE FUND — Merchants Guild
// ═══════════════════════════════════════════════════════════════════════════

export function initHedgeFund() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS fund_state (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS fund_members (
      player_id   TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
      shares      REAL    NOT NULL DEFAULT 0,
      deposited   REAL    NOT NULL DEFAULT 0,
      joined_at   INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS fund_holdings (
      symbol TEXT PRIMARY KEY,
      qty    INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS fund_proposals (
      id          TEXT PRIMARY KEY,
      proposer_id TEXT NOT NULL REFERENCES players(id),
      side        TEXT NOT NULL,
      symbol      TEXT NOT NULL,
      qty         INTEGER NOT NULL,
      reason      TEXT,
      created_at  INTEGER NOT NULL,
      expires_at  INTEGER NOT NULL,
      status      TEXT NOT NULL DEFAULT 'open',
      votes_yes   INTEGER NOT NULL DEFAULT 0,
      votes_no    INTEGER NOT NULL DEFAULT 0,
      executed_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS fund_votes (
      proposal_id TEXT NOT NULL REFERENCES fund_proposals(id),
      player_id   TEXT NOT NULL REFERENCES players(id),
      vote        TEXT NOT NULL,
      weight      INTEGER NOT NULL DEFAULT 1,
      voted_at    INTEGER NOT NULL,
      PRIMARY KEY (proposal_id, player_id)
    );

    CREATE TABLE IF NOT EXISTS fund_ledger (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      ts         INTEGER NOT NULL,
      type       TEXT NOT NULL,
      player_id  TEXT,
      symbol     TEXT,
      qty        INTEGER,
      price      REAL,
      amount     REAL,
      shares_delta REAL,
      note       TEXT
    );
  `);

  // Init fund cash if not set
  const row = stmt('SELECT value FROM fund_state WHERE key=?').get('cash');
  if (!row) stmt('INSERT INTO fund_state VALUES(?,?)').run('cash', '0');
}

// ── Fund state ────────────────────────────────────────────────────────────────

export function getFundCash() {
  const r = stmt('SELECT value FROM fund_state WHERE key=?').get('cash');
  return r ? parseFloat(r.value) || 0 : 0;
}
export function setFundCash(v) {
  stmt('INSERT OR REPLACE INTO fund_state VALUES(?,?)').run('cash', String(v));
}
export function getFundHoldings() {
  return stmt('SELECT symbol, qty FROM fund_holdings WHERE qty>0').all();
}
export function setFundHolding(symbol, qty) {
  if (qty <= 0) stmt('DELETE FROM fund_holdings WHERE symbol=?').run(symbol);
  else stmt('INSERT OR REPLACE INTO fund_holdings VALUES(?,?)').run(symbol, qty);
}
export function getTotalFundShares() {
  const r = stmt('SELECT SUM(shares) as s FROM fund_members').get();
  return r?.s || 0;
}

// ── Membership ────────────────────────────────────────────────────────────────

export function getFundMembers() {
  return stmt(`
    SELECT fm.player_id, fm.shares, fm.deposited, fm.joined_at, p.name, p.patreon_tier
    FROM fund_members fm JOIN players p ON p.id=fm.player_id
    ORDER BY fm.shares DESC
  `).all();
}
export function getFundMember(playerId) {
  return stmt('SELECT * FROM fund_members WHERE player_id=?').get(playerId);
}
export function isFundMember(playerId) {
  return !!stmt('SELECT 1 FROM fund_members WHERE player_id=?').get(playerId);
}

// Auto-join eligible players (tier >= 2)
export function syncFundMembership() {
  // MERCHANTS_GUILD — Patreon tier >= 2 (regular players), plus the owner account (is_prime)
  // Regular devs/admins do NOT get auto-enrolled in MERCHANTS_GUILD — they belong in FLSH only
  const guildEligible = stmt('SELECT id FROM players WHERE patreon_tier>=2 OR is_prime=1').all();
  for (const p of guildEligible) {
    if (!isInFund('MERCHANTS_GUILD', p.id)) {
      try { joinFund('MERCHANTS_GUILD', p.id); } catch(_) {}
    }
  }
  // FLSH Capital — all dev/admin accounts (including owner)
  const devEligible = stmt('SELECT id FROM players WHERE is_dev=1 OR is_admin=1').all();
  for (const p of devEligible) {
    if (!isInFund('FLSH', p.id)) {
      try { joinFund('FLSH', p.id); } catch(_) {}
    }
  }
  // Remove non-prime devs from MERCHANTS_GUILD if they snuck in
  try {
    stmt(`DELETE FROM fund_memberships
          WHERE fund_id='MERCHANTS_GUILD'
          AND player_id IN (
            SELECT id FROM players WHERE (is_dev=1 OR is_admin=1) AND is_prime=0
          )`).run();
  } catch(_) {}
}

// ── Deposit / Withdraw ────────────────────────────────────────────────────────

export let depositToFundFn;
export let withdrawFromFundFn;

export function setupFundTransactions() {
  depositToFundFn = transaction((playerId, amount, currentNAV) => {
    const player = getPlayer(playerId);
    if (!player || player.cash < amount) throw new Error('insufficient_funds');
    if (!isFundMember(playerId)) throw new Error('not_a_member');

    const totalShares = getTotalFundShares();
    const pricePerShare = totalShares > 0 && currentNAV > 0 ? currentNAV / totalShares : 1;
    const newShares = amount / pricePerShare;

    stmt('UPDATE players SET cash=cash-?,updated_at=? WHERE id=?').run(amount, Date.now(), playerId);
    stmt(`INSERT INTO fund_members(player_id,shares,deposited,joined_at) VALUES(?,?,?,?)
          ON CONFLICT(player_id) DO UPDATE SET shares=shares+?,deposited=deposited+?`)
      .run(playerId, newShares, amount, Date.now(), newShares, amount);
    setFundCash(getFundCash() + amount);

    stmt('INSERT INTO fund_ledger(ts,type,player_id,amount,shares_delta,note) VALUES(?,?,?,?,?,?)')
      .run(Date.now(), 'deposit', playerId, amount, newShares, `Deposit at NAV ₥${currentNAV.toFixed(2)}`);

    return newShares;
  });

  withdrawFromFundFn = transaction((playerId, sharesFraction, currentNAV) => {
    const member = getFundMember(playerId);
    if (!member) throw new Error('not_a_member');
    const shares = member.shares * Math.min(1, Math.max(0, sharesFraction));
    if (shares <= 0) throw new Error('no_shares');

    const totalShares = getTotalFundShares();
    const pricePerShare = totalShares > 0 && currentNAV > 0 ? currentNAV / totalShares : 1;
    const cashValue = shares * pricePerShare;

    // Pay out from fund cash first, liquidate holdings if needed
    const fundCash = getFundCash();
    if (fundCash < cashValue) throw new Error('insufficient_fund_liquidity');

    setFundCash(fundCash - cashValue);
    stmt('UPDATE players SET cash=cash+?,updated_at=? WHERE id=?').run(cashValue, Date.now(), playerId);
    stmt('UPDATE fund_members SET shares=shares-? WHERE player_id=?').run(shares, playerId);

    stmt('INSERT INTO fund_ledger(ts,type,player_id,amount,shares_delta,note) VALUES(?,?,?,?,?,?)')
      .run(Date.now(), 'withdraw', playerId, cashValue, -shares, `Withdraw ${(sharesFraction*100).toFixed(0)}% of shares`);

    return cashValue;
  });
}

// ── Proposals & Voting ────────────────────────────────────────────────────────

export function createProposal(proposerId, side, symbol, qty, reason) {
  const id = Math.random().toString(36).slice(2,10).toUpperCase();
  const now = Date.now();
  stmt(`INSERT INTO fund_proposals(id,proposer_id,side,symbol,qty,reason,created_at,expires_at,status)
        VALUES(?,?,?,?,?,?,?,?,'open')`)
    .run(id, proposerId, side, symbol, qty, reason||'', now, now + 48*60*60*1000);
  return id;
}

export function getOpenProposals() {
  return stmt(`SELECT p.*, pl.name as proposer_name
               FROM fund_proposals p JOIN players pl ON pl.id=p.proposer_id
               WHERE p.status='open' AND p.expires_at>?
               ORDER BY p.created_at DESC`)
    .all(Date.now());
}

export function getAllProposals(limit=20) {
  return stmt(`SELECT p.*, pl.name as proposer_name
               FROM fund_proposals p JOIN players pl ON pl.id=p.proposer_id
               ORDER BY p.created_at DESC LIMIT ?`)
    .all(limit);
}

export function castVote(proposalId, playerId, vote, weight) {
  const existing = stmt('SELECT 1 FROM fund_votes WHERE proposal_id=? AND player_id=?').get(proposalId, playerId);
  if (existing) throw new Error('already_voted');
  stmt('INSERT INTO fund_votes VALUES(?,?,?,?,?)').run(proposalId, playerId, vote, weight||1, Date.now());
  if (vote === 'yes') stmt('UPDATE fund_proposals SET votes_yes=votes_yes+? WHERE id=?').run(weight||1, proposalId);
  else stmt('UPDATE fund_proposals SET votes_no=votes_no+? WHERE id=?').run(weight||1, proposalId);
  return getProposal(proposalId);
}

export function getProposal(id) {
  return stmt(`SELECT p.*, pl.name as proposer_name
               FROM fund_proposals p JOIN players pl ON pl.id=p.proposer_id
               WHERE p.id=?`).get(id);
}

export function hasVoted(proposalId, playerId) {
  return !!stmt('SELECT 1 FROM fund_votes WHERE proposal_id=? AND player_id=?').get(proposalId, playerId);
}

export function resolveProposal(id, status, executedAt) {
  stmt('UPDATE fund_proposals SET status=?,executed_at=? WHERE id=?').run(status, executedAt||Date.now(), id);
}

export function expireOldProposals() {
  stmt(`UPDATE fund_proposals SET status='expired' WHERE status='open' AND expires_at<?`).run(Date.now());
}

// Fund ledger (activity log)
export function getFundLedger(limit=50) {
  return stmt(`SELECT l.*, p.name as player_name FROM fund_ledger l
               LEFT JOIN players p ON p.id=l.player_id
               ORDER BY l.ts DESC LIMIT ?`).all(limit);
}

export function logFundTrade(symbol, side, qty, price, note) {
  stmt('INSERT INTO fund_ledger(ts,type,symbol,qty,price,note) VALUES(?,?,?,?,?,?)')
    .run(Date.now(), `trade_${side}`, symbol, qty, price, note||'');
}

// ═══════════════════════════════════════════════════════════════════════════
// PLAYER FUNDS SYSTEM (general multi-fund)
// ═══════════════════════════════════════════════════════════════════════════

export const FUND_CREATE_COST  = 10_000_000;   // ₥10M to start a fund
export const FUND_SLOT_COST    = 150_000;       // ₥150K per extra member slot
export const FUND_BASE_SLOTS   = 5;             // slots included in creation cost
export const FUND_SAVINGS_RATE = 0.0004;        // 0.04% per hour on idle cash (~1%/day)
export const FLSH_TRADE_PCT    = 0.05;          // 5% of trade volume goes to FLSH fund

export function initFundsSystem() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS funds (
      id           TEXT PRIMARY KEY,
      name         TEXT NOT NULL UNIQUE COLLATE NOCASE,
      type         TEXT NOT NULL DEFAULT 'player',
      owner_id     TEXT REFERENCES players(id),
      description  TEXT,
      max_members  INTEGER NOT NULL DEFAULT 5,
      slot_cost    REAL NOT NULL DEFAULT 150000,
      savings_rate REAL NOT NULL DEFAULT 0.0004,
      cash         REAL NOT NULL DEFAULT 0,
      created_at   INTEGER NOT NULL,
      closed_at    INTEGER
    );

    CREATE TABLE IF NOT EXISTS fund_memberships (
      fund_id    TEXT NOT NULL REFERENCES funds(id) ON DELETE CASCADE,
      player_id  TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      shares     REAL NOT NULL DEFAULT 0,
      deposited  REAL NOT NULL DEFAULT 0,
      joined_at  INTEGER NOT NULL,
      PRIMARY KEY (fund_id, player_id)
    );

    CREATE TABLE IF NOT EXISTS fund_portfolios (
      fund_id TEXT NOT NULL REFERENCES funds(id) ON DELETE CASCADE,
      symbol  TEXT NOT NULL,
      qty     INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (fund_id, symbol)
    );

    CREATE TABLE IF NOT EXISTS fund_activity (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      fund_id   TEXT NOT NULL REFERENCES funds(id) ON DELETE CASCADE,
      ts        INTEGER NOT NULL,
      type      TEXT NOT NULL,
      player_id TEXT,
      symbol    TEXT,
      qty       INTEGER,
      price     REAL,
      amount    REAL,
      note      TEXT
    );
  `);

  // Seed special funds if not present
  const now = Date.now();
  const existing = stmt('SELECT id FROM funds').all().map(r => r.id);

  if (!existing.includes('FLSH')) {
    stmt(`INSERT INTO funds(id,name,type,owner_id,description,max_members,slot_cost,savings_rate,cash,created_at)
          VALUES('FLSH','FLSH Capital','flsh',null,'Developer fund. Revenue from all platform trade fees.',999,0,0.0004,1000000000000,?)`)
      .run(now);
  }

  if (!existing.includes('MERCHANTS_GUILD')) {
    stmt(`INSERT INTO funds(id,name,type,owner_id,description,max_members,slot_cost,savings_rate,cash,created_at)
          VALUES('MERCHANTS_GUILD','Merchants Guild','patreon',null,'Exclusive Patreon hedge fund. Membership via patreon.com/FLSH.',9999,0,0.0004,0,?)`)
      .run(now);
  } else {
    // Uncap existing guild (in case DB was created before this change)
    stmt(`UPDATE funds SET max_members=9999 WHERE id='MERCHANTS_GUILD' AND max_members < 9999`).run();
  }

  console.log('[DB] Funds system ready');
}

// ── Fund CRUD ─────────────────────────────────────────────────────────────────

export function getAllFunds() {
  return stmt('SELECT * FROM funds WHERE closed_at IS NULL ORDER BY created_at ASC').all();
}
export function getFund(id) {
  return stmt('SELECT * FROM funds WHERE id=?').get(id);
}
export function getFundByName(name) {
  return stmt('SELECT * FROM funds WHERE name=? COLLATE NOCASE').get(name);
}
export function createFund(id, name, ownerId, description, maxMembers) {
  const now = Date.now();
  stmt(`INSERT INTO funds(id,name,type,owner_id,description,max_members,slot_cost,savings_rate,cash,created_at)
        VALUES(?,?,'player',?,?,?,150000,0.0004,0,?)`)
    .run(id, name, ownerId, description||'', maxMembers||FUND_BASE_SLOTS, now);
  // Owner auto-joins
  stmt('INSERT INTO fund_memberships(fund_id,player_id,shares,deposited,joined_at) VALUES(?,?,0,0,?)')
    .run(id, ownerId, now);
}

export function addFundSlots(fundId, count) {
  stmt('UPDATE funds SET max_members=max_members+? WHERE id=?').run(count, fundId);
}

// ── Fund membership ───────────────────────────────────────────────────────────

export function getFundMemberships(fundId) {
  return stmt(`SELECT fm.*,p.name,p.patreon_tier FROM fund_memberships fm
               JOIN players p ON p.id=fm.player_id WHERE fm.fund_id=? ORDER BY fm.shares DESC`).all(fundId);
}
export function getFundMembership(fundId, playerId) {
  return stmt('SELECT * FROM fund_memberships WHERE fund_id=? AND player_id=?').get(fundId, playerId);
}
export function isInFund(fundId, playerId) {
  return !!stmt('SELECT 1 FROM fund_memberships WHERE fund_id=? AND player_id=?').get(fundId, playerId);
}
export function getFundMemberCount(fundId) {
  return (stmt('SELECT COUNT(*) as n FROM fund_memberships WHERE fund_id=?').get(fundId)||{n:0}).n;
}
export function joinFund(fundId, playerId) {
  if (isInFund(fundId, playerId)) throw new Error('already_member');
  const fund = getFund(fundId);
  if (!fund) throw new Error('fund_not_found');
  if (getFundMemberCount(fundId) >= fund.max_members) throw new Error('fund_full');
  stmt('INSERT INTO fund_memberships(fund_id,player_id,shares,deposited,joined_at) VALUES(?,?,0,0,?)')
    .run(fundId, playerId, Date.now());
}

// ── Fund cash & holdings ──────────────────────────────────────────────────────

export function getFundCashById(fundId) {
  return (getFund(fundId)?.cash) || 0;
}
export function setFundCashById(fundId, v) {
  stmt('UPDATE funds SET cash=? WHERE id=?').run(v, fundId);
}
export function addFundCash(fundId, delta) {
  stmt('UPDATE funds SET cash=cash+? WHERE id=?').run(delta, fundId);
}
export function getFundPortfolio(fundId) {
  return stmt('SELECT symbol,qty FROM fund_portfolios WHERE fund_id=? AND qty>0').all(fundId);
}
export function setFundPortfolioQty(fundId, symbol, qty) {
  if (qty <= 0) stmt('DELETE FROM fund_portfolios WHERE fund_id=? AND symbol=?').run(fundId, symbol);
  else stmt('INSERT OR REPLACE INTO fund_portfolios VALUES(?,?,?)').run(fundId, symbol, qty);
}
export function getTotalFundSharesById(fundId) {
  return (stmt('SELECT SUM(shares) as s FROM fund_memberships WHERE fund_id=?').get(fundId)||{s:0}).s || 0;
}

// ── Savings interest ──────────────────────────────────────────────────────────
// Call every hour — credits interest to all fund cash balances

export function applyFundSavingsInterest() {
  const funds = getAllFunds();
  let total = 0;
  for (const f of funds) {
    if (f.cash <= 0 || f.savings_rate <= 0) continue;
    const interest = f.cash * f.savings_rate;
    stmt('UPDATE funds SET cash=cash+? WHERE id=?').run(interest, f.id);
    stmt('INSERT INTO fund_activity(fund_id,ts,type,amount,note) VALUES(?,?,?,?,?)')
      .run(f.id, Date.now(), 'interest', interest, `Hourly savings: ${(f.savings_rate*100).toFixed(3)}%`);
    total += interest;
  }
  return total;
}

// ── Deposit / Withdraw ────────────────────────────────────────────────────────

export let fundDepositFn;
export let fundWithdrawFn;

export function setupFundDepositWithdraw() {
  fundDepositFn = transaction((fundId, playerId, amount) => {
    const fund = getFund(fundId); if (!fund) throw new Error('fund_not_found');
    const player = getPlayer(playerId); if (!player) throw new Error('not_found');
    if (player.cash < amount) throw new Error('insufficient_funds');
    if (!isInFund(fundId, playerId)) throw new Error('not_a_member');

    const currentNAV   = getFundNAVById(fundId, null); // pass null, compute internally
    const totalShares  = getTotalFundSharesById(fundId);
    const pricePerShare = totalShares > 0 && currentNAV > 0 ? currentNAV / totalShares : 1;
    const newShares    = amount / pricePerShare;

    stmt('UPDATE players SET cash=cash-?,updated_at=? WHERE id=?').run(amount, Date.now(), playerId);
    stmt('UPDATE funds SET cash=cash+? WHERE id=?').run(amount, fundId);
    stmt(`UPDATE fund_memberships SET shares=shares+?,deposited=deposited+? WHERE fund_id=? AND player_id=?`)
      .run(newShares, amount, fundId, playerId);
    stmt('INSERT INTO fund_activity(fund_id,ts,type,player_id,amount,note) VALUES(?,?,?,?,?,?)')
      .run(fundId, Date.now(), 'deposit', playerId, amount, `${player.name} deposited ₥${amount.toFixed(2)}`);
    return newShares;
  });

  fundWithdrawFn = transaction((fundId, playerId, pct, currentNAV) => {
    const member = getFundMembership(fundId, playerId); if (!member) throw new Error('not_a_member');
    const shares = member.shares * Math.min(1, Math.max(0.01, pct));
    if (shares <= 0) throw new Error('no_shares');
    const totalShares  = getTotalFundSharesById(fundId);
    const pricePerShare = totalShares > 0 && currentNAV > 0 ? currentNAV / totalShares : 1;
    const cashValue    = shares * pricePerShare;
    const fundCash     = getFundCashById(fundId);
    if (fundCash < cashValue) throw new Error('insufficient_fund_liquidity');
    stmt('UPDATE funds SET cash=cash-? WHERE id=?').run(cashValue, fundId);
    stmt('UPDATE players SET cash=cash+?,updated_at=? WHERE id=?').run(cashValue, Date.now(), playerId);
    stmt('UPDATE fund_memberships SET shares=shares-? WHERE fund_id=? AND player_id=?').run(shares, fundId, playerId);
    stmt('INSERT INTO fund_activity(fund_id,ts,type,player_id,amount,note) VALUES(?,?,?,?,?,?)')
      .run(fundId, Date.now(), 'withdraw', playerId, cashValue, `Withdrew ${(pct*100).toFixed(0)}% of shares`);
    return cashValue;
  });
}

// NAV helper (needs live prices — pass holdings + prices map)
export function getFundNAVById(fundId, priceMap) {
  const cash     = getFundCashById(fundId);
  const holdings = getFundPortfolio(fundId);
  const equity   = priceMap
    ? holdings.reduce((acc, h) => acc + (priceMap[h.symbol] || 0) * h.qty, 0)
    : 0;
  return cash + equity;
}

// ── Activity log ──────────────────────────────────────────────────────────────

export function getFundActivity(fundId, limit=30) {
  return stmt(`SELECT a.*,p.name as player_name FROM fund_activity a
               LEFT JOIN players p ON p.id=a.player_id
               WHERE a.fund_id=? ORDER BY a.ts DESC LIMIT ?`).all(fundId, limit);
}
export function logFundActivity(fundId, type, playerId, symbol, qty, price, amount, note) {
  stmt('INSERT INTO fund_activity(fund_id,ts,type,player_id,symbol,qty,price,amount,note) VALUES(?,?,?,?,?,?,?,?,?)')
    .run(fundId, Date.now(), type, playerId||null, symbol||null, qty||null, price||null, amount||null, note||null);
}

// ── Dev accounts ──────────────────────────────────────────────────────────────

export function setDevAccount(playerId, isDev) {
  // Lazy add is_dev column
  try { db.exec('ALTER TABLE players ADD COLUMN is_dev INTEGER NOT NULL DEFAULT 0'); } catch(_){}
  stmt('UPDATE players SET is_dev=? WHERE id=?').run(isDev ? 1 : 0, playerId);
}
export function isDevAccount(playerId) {
  try {
    const row = stmt('SELECT is_dev FROM players WHERE id=?').get(playerId);
    return !!(row?.is_dev);
  } catch(_) { return false; }
}

// Sync dev accounts from env on startup — also auto-enrolls them into fleshstation faction
export function syncDevAccounts(devNames) {
  if (!devNames || !devNames.length) return;
  try { db.exec('ALTER TABLE players ADD COLUMN is_dev   INTEGER NOT NULL DEFAULT 0'); } catch(_){}
  try { db.exec('ALTER TABLE players ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0'); } catch(_){}
  try { db.exec('ALTER TABLE players ADD COLUMN is_prime INTEGER NOT NULL DEFAULT 0'); } catch(_){}
  try { db.exec('ALTER TABLE players ADD COLUMN faction TEXT'); } catch(_){}
  // Reset all devs first
  stmt('UPDATE players SET is_dev=0, is_admin=0').run();
  for (const name of devNames) {
    const p = getPlayerByName(name.trim());
    if (p) {
      stmt('UPDATE players SET is_dev=1, is_admin=1, faction=? WHERE id=?').run('fleshstation', p.id);
      console.log(`[Dev] Flagged ${p.name} as dev → Flesh Station faction`);
    }
  }
}

export function isOwnerAccount(playerId) {
  try {
    try { db.exec('ALTER TABLE players ADD COLUMN is_prime INTEGER NOT NULL DEFAULT 0'); } catch(_){}
    const row = stmt('SELECT is_prime FROM players WHERE id=?').get(playerId);
    return !!(row?.is_prime);
  } catch(_) { return false; }
}

// Bulk-fetch all player factions (for server-side passive bonus computation)
export function getPlayerFactionsBulk() {
  try {
    const rows = stmt('SELECT id, faction FROM players WHERE faction IS NOT NULL').all();
    const map = {};
    for (const r of rows) map[r.id] = r.faction;
    return map;
  } catch(_) { return {}; }
}

// ─── Admin / Moderation ───────────────────────────────────────────────────────

export function isAdminAccount(playerId) {
  try {
    // Lazy-add column if needed
    try { db.exec('ALTER TABLE players ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0'); } catch(_) {}
    const row = stmt('SELECT is_admin, is_dev FROM players WHERE id=?').get(playerId);
    return !!(row?.is_admin || row?.is_dev); // dev accounts are always admin
  } catch(_) { return false; }
}

export function setAdminAccount(playerId, isAdmin) {
  try { db.exec('ALTER TABLE players ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0'); } catch(_) {}
  stmt('UPDATE players SET is_admin=? WHERE id=?').run(isAdmin ? 1 : 0, playerId);
}

// Persist mutes to DB so they survive server restarts
export function initModerationTable() {
  db.exec(`CREATE TABLE IF NOT EXISTS moderation (
    player_id  TEXT PRIMARY KEY,
    muted_until INTEGER NOT NULL DEFAULT 0,
    banned_until INTEGER NOT NULL DEFAULT 0,
    muted_by    TEXT,
    reason      TEXT,
    is_dunced   INTEGER NOT NULL DEFAULT 0,
    dunce_by    TEXT,
    dunce_reason TEXT
  )`);
  // Migration: add dunce columns if they don't exist yet
  try { db.exec(`ALTER TABLE moderation ADD COLUMN is_dunced INTEGER NOT NULL DEFAULT 0`); } catch(_) {}
  try { db.exec(`ALTER TABLE moderation ADD COLUMN dunce_by TEXT`); } catch(_) {}
  try { db.exec(`ALTER TABLE moderation ADD COLUMN dunce_reason TEXT`); } catch(_) {}
}

export function setDunce(targetId, duncedBy, reason) {
  stmt(`INSERT INTO moderation (player_id, is_dunced, dunce_by, dunce_reason)
    VALUES (?,1,?,?)
    ON CONFLICT(player_id) DO UPDATE SET is_dunced=1,
      dunce_by=excluded.dunce_by, dunce_reason=excluded.dunce_reason`
  ).run(targetId, duncedBy || '', reason || '');
}

export function clearDunce(targetId) {
  stmt(`UPDATE moderation SET is_dunced=0 WHERE player_id=?`).run(targetId);
}

export function isDunced(targetId) {
  try {
    const row = stmt('SELECT is_dunced FROM moderation WHERE player_id=?').get(targetId);
    return !!(row?.is_dunced);
  } catch(_) { return false; }
}

export function getDunceRecord(targetId) {
  try {
    const row = stmt('SELECT dunce_by, dunce_reason FROM moderation WHERE player_id=?').get(targetId);
    return row || null;
  } catch(_) { return null; }
}

export function setMute(targetId, mutedUntilMs, mutedBy, reason) {
  stmt(`INSERT INTO moderation (player_id, muted_until, muted_by, reason)
    VALUES (?,?,?,?)
    ON CONFLICT(player_id) DO UPDATE SET muted_until=excluded.muted_until,
      muted_by=excluded.muted_by, reason=excluded.reason`
  ).run(targetId, mutedUntilMs, mutedBy || '', reason || '');
}

export function clearMute(targetId) {
  stmt(`UPDATE moderation SET muted_until=0 WHERE player_id=?`).run(targetId);
}

export function isMuted(targetId) {
  try {
    const row = stmt('SELECT muted_until FROM moderation WHERE player_id=?').get(targetId);
    if (!row) return false;
    return row.muted_until > Date.now();
  } catch(_) { return false; }
}

export function getMuteExpiry(targetId) {
  try {
    const row = stmt('SELECT muted_until FROM moderation WHERE player_id=?').get(targetId);
    return row?.muted_until || 0;
  } catch(_) { return 0; }
}

export function setBan(targetId, bannedUntilMs, bannedBy, reason) {
  stmt(`INSERT INTO moderation (player_id, banned_until, muted_by, reason)
    VALUES (?,0,?,?)
    ON CONFLICT(player_id) DO UPDATE SET banned_until=excluded.banned_until,
      muted_by=excluded.muted_by, reason=excluded.reason`
  ).run(targetId, bannedBy || '', reason || '');
  stmt('UPDATE moderation SET banned_until=? WHERE player_id=?').run(bannedUntilMs, targetId);
}

export function isBanned(targetId) {
  try {
    const row = stmt('SELECT banned_until FROM moderation WHERE player_id=?').get(targetId);
    if (!row) return false;
    return row.banned_until > Date.now();
  } catch(_) { return false; }
}

export function getModerationRecord(targetId) {
  try {
    return stmt('SELECT * FROM moderation WHERE player_id=?').get(targetId) || null;
  } catch(_) { return null; }
}

// ─── Galaxy: Colony State ─────────────────────────────────────────────────────

// Default colony data — seeded on first access
const COLONY_DEFAULTS = [
  { id:'new_anchor',       faction:'coalition',    control_coalition:82, control_syndicate:12, control_void:6,  tension:18, contested:0 },
  { id:'cascade_station',  faction:'coalition',    control_coalition:68, control_syndicate:20, control_void:12, tension:32, contested:1 },
  { id:'frontier_outpost', faction:'coalition',    control_coalition:51, control_syndicate:38, control_void:11, tension:49, contested:1 },
  { id:'the_hollow',       faction:'syndicate',    control_coalition:15, control_syndicate:74, control_void:11, tension:26, contested:0 },
  { id:'vein_cluster',     faction:'syndicate',    control_coalition:8,  control_syndicate:71, control_void:21, tension:29, contested:0 },
  { id:'aurora_prime',     faction:'coalition',    control_coalition:76, control_syndicate:10, control_void:14, tension:24, contested:0 },
  { id:'null_point',       faction:'void',         control_coalition:5,  control_syndicate:22, control_void:73, tension:22, contested:0 },
  { id:'flesh_station',    faction:'fleshstation', control_coalition:0,  control_syndicate:0,  control_void:0,  tension:0,  contested:0 },
];

export function seedColoniesIfEmpty() {
  const count = (stmt('SELECT COUNT(*) as c FROM colony_state').get()||{c:0}).c;
  if (count > 0) return;
  for (const c of COLONY_DEFAULTS) {
    stmt(`INSERT OR IGNORE INTO colony_state
      (id,faction,control_coalition,control_syndicate,control_void,tension,contested,war_chest)
      VALUES(?,?,?,?,?,?,?,0)`)
      .run(c.id, c.faction, c.control_coalition, c.control_syndicate, c.control_void, c.tension, c.contested);
  }
  console.log('[Galaxy] Colony state seeded');
}

export function getAllColonyStates() {
  return stmt('SELECT * FROM colony_state').all();
}

export function getColonyState(colonyId) {
  return stmt('SELECT * FROM colony_state WHERE id=?').get(colonyId) || null;
}

export function updateColonyState(colonyId, fields) {
  const sets = Object.keys(fields).map(k => `${k}=?`).join(',');
  const vals = Object.values(fields);
  stmt(`UPDATE colony_state SET ${sets} WHERE id=?`).run(...vals, colonyId);
}

export function getColonyTopFunders(colonyId, factionId, limit=5) {
  return stmt(`SELECT player_id, SUM(amount) as total FROM faction_funding
               WHERE colony_id=? AND faction_id=? GROUP BY player_id
               ORDER BY total DESC LIMIT ?`).all(colonyId, factionId, limit);
}

export function recordFactionFunding(playerId, colonyId, factionId, amount) {
  stmt(`INSERT INTO faction_funding(player_id,colony_id,faction_id,amount,ts)
        VALUES(?,?,?,?,?)`).run(playerId, colonyId, factionId, amount, Date.now());
  stmt('UPDATE colony_state SET war_chest=war_chest+? WHERE id=?').run(amount, colonyId);
}

export function getPlayerFactionFunding(playerId, colonyId) {
  return stmt(`SELECT faction_id, SUM(amount) as total FROM faction_funding
               WHERE player_id=? AND colony_id=? GROUP BY faction_id`).all(playerId, colonyId);
}

// ─── Galaxy: Player Faction ───────────────────────────────────────────────────

export function setPlayerFaction(playerId, factionId) {
  try { db.exec('ALTER TABLE players ADD COLUMN faction TEXT'); } catch(_){}
  stmt('UPDATE players SET faction=?,updated_at=? WHERE id=?').run(factionId||null, Date.now(), playerId);
}

export function getPlayerFaction(playerId) {
  try {
    const row = stmt('SELECT faction FROM players WHERE id=?').get(playerId);
    return row?.faction || null;
  } catch(_) { return null; }
}

