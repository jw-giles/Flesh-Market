/**
 * FleshMarket — Server v5.0 "Full Flesh"
 * New in v5.0:
 *   - Limit Orders (buy & sell, in-memory, auto-fill on tick, 24h expiry)
 *   - Short Selling (negative holdings, borrow fee every 30min)
 *   - Earnings Events (every 8min, notifies holders)
 *   - IPO Events (every 90min, 15-35% discount, 90s window)
 *   - Dividends (every 2h, Finance/Insurance/Energy/Tech sectors)
 *   - Trade Feed (anonymized broadcast on every fill)
 *   - XP: scales with trade value, profit bonus on sells, IPO/dividend rewards
 *   - Heatmap data (pct change per tick broadcast)
 *   - Tick includes sector per ticker
 */

import 'dotenv/config';
import express from 'express';
import { WebSocketServer } from 'ws';
import { v4 as uuidv4 } from 'uuid';
import { createHmac } from 'crypto';
import http from 'http';
import path from 'path';
import url  from 'url';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));

import { filterChat } from './chat-filter.js';

import {
  initDB, setupTransactions,
  createPlayerSync, getPlayer, getPlayerByName,
  getPlayerByPatreonEmail, getPlayerByPatreonMemberId,
  isNameAvailable, touchPlayer, renamePlayer,
  savePlayerFn, recordNetWorthFn,
  getNetWorthHistory, getLeaderboard,
  verifyPassword, createPasswordHash,
  saveMarketState, loadMarketState,
  setPatreonTier, linkPatreonEmail,
  revokeExpiredPatreon, creditPassiveIncome, DEV_INCOME_EVERY30,
  countCEOs, TIERS, CEO_MAX,
  initHedgeFund, setupFundTransactions,
  getFundCash, setFundCash, getFundHoldings, setFundHolding,
  getTotalFundShares, getFundMembers, getFundMember, isFundMember,
  syncFundMembership, depositToFundFn, withdrawFromFundFn,
  createProposal, getOpenProposals, getAllProposals,
  castVote, getProposal, hasVoted, resolveProposal,
  expireOldProposals, getFundLedger, logFundTrade,
  initFundsSystem, setupFundDepositWithdraw,
  getAllFunds, getFund, getFundByName, createFund, addFundSlots,
  getFundMemberships, getFundMembership, isInFund, getFundMemberCount, joinFund,
  getFundCashById, setFundCashById, addFundCash,
  getFundPortfolio, setFundPortfolioQty, getTotalFundSharesById,
  getFundNAVById, applyFundSavingsInterest,
  fundDepositFn, fundWithdrawFn,
  getFundActivity, logFundActivity,
  setDevAccount, isDevAccount, syncDevAccounts,
  isAdminAccount, setAdminAccount, isOwnerAccount, initModerationTable,
  setMute, clearMute, isMuted, getMuteExpiry,
  setBan, isBanned, getModerationRecord,
  setDunce, clearDunce, isDunced, getDunceRecord,
  FUND_CREATE_COST, FUND_SLOT_COST, FUND_BASE_SLOTS, FLSH_TRADE_PCT,
  // Galaxy
  seedColoniesIfEmpty, getAllColonyStates, getColonyState, updateColonyState,
  recordFactionFunding, getColonyTopFunders, getPlayerFactionFunding,
  setPlayerFaction, getPlayerFaction, getPlayerFactionsBulk,
} from './db.js';

initDB();
setupTransactions();
initHedgeFund();
setupFundTransactions();
initFundsSystem();
setupFundDepositWithdraw();
initModerationTable();
seedColoniesIfEmpty();

function savePlayer(p) { try { savePlayerFn(p); } catch(e) { console.error('savePlayer:', e); } }
function recordNetWorth(id, net, cash, equity) { try { recordNetWorthFn(id, net, cash, equity); } catch(e) {} }

// ─── Config ───────────────────────────────────────────────────────────────────

const PORT          = process.env.PORT || 7777;
const TICK_MS       = 500;
const NEWS_MS       = 7132;
const START_CASH    = 1000;
const TAX_RATE      = 0.02;
const MAX_SHARES    = 1_000_000;
const TRADE_TAX_BPS = parseInt(process.env.TRADE_TAX_BPS || '25', 10);
const PATREON_WEBHOOK_SECRET = process.env.PATREON_WEBHOOK_SECRET || '';
const INCOME_INTERVAL_MS = 30 * 60 * 1000;

// v5.0 config
const EARNINGS_INTERVAL_MS  = 8  * 60 * 1000;  // 8 minutes
const IPO_INTERVAL_MS       = 90 * 60 * 1000;  // 90 minutes
const IPO_WINDOW_MS         = 90 * 1000;        // 90 second window
const DIVIDEND_INTERVAL_MS  = 2  * 60 * 60 * 1000; // 2 hours
const BORROW_INTERVAL_MS    = 30 * 60 * 1000;   // 30 minutes
const BORROW_RATE           = 0.001;  // 0.1% of position value per 30min
const SHORT_MARGIN_RATE     = 0.50;   // 50% of short value required as cash collateral
const MAX_SHORT_PER_SYM     = 500;    // hard cap: max shares short per symbol per player
const DIVIDEND_RATE         = 0.006;  // 0.6% of position value per 2h
const DIVIDEND_SECTORS      = new Set([0, 2, 4, 6]); // Finance, Insurance, Energy, Tech
const SECTOR_NAMES          = ['Finance','Biotech','Insurance','Manufacturing','Energy','Logistics','Tech','Misc'];

// DEV_ACCOUNTS env: comma-separated list of dev account names.
// Must include 'MrFlesh' — e.g. DEV_ACCOUNTS=MrFlesh,DEV-FIXER,DEV-SLUT,DEV-SMASHER,DEV-GURU,DEV-PEAK
// MrFlesh is the prime/owner account (is_prime=1 set by seed_devaccounts.mjs).
const DEV_ACCOUNTS = (process.env.DEV_ACCOUNTS || '').split(',').map(s=>s.trim()).filter(Boolean);

// ─── RNG ──────────────────────────────────────────────────────────────────────

let __SEED = 0x9E3779B9;
function seededRand() {
  let x = __SEED>>>0; x^=x<<13; x^=x>>>17; x^=x<<5; __SEED=x>>>0;
  return (__SEED>>>0)/4294967296;
}
let __haveSpare=false,__spare=0;
function randn() {
  if(__haveSpare){__haveSpare=false;return __spare;}
  let u=0,v=0; while(u===0)u=seededRand(); while(v===0)v=seededRand();
  const r=Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);
  __spare=Math.sqrt(-2*Math.log(u))*Math.sin(2*Math.PI*v); __haveSpare=true; return r;
}
const MARKET_SEED=1337;
function hashStr(s){let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function rngSeeded(sym,key){let x=(hashStr(String(sym))^hashStr(String(key))^MARKET_SEED)>>>0;x^=x<<13;x^=x>>>17;x^=x<<5;return((x>>>0)/4294967296);}
const rng=(min,max)=>Math.random()*(max-min)+min;
const pick=arr=>arr[Math.floor(Math.random()*arr.length)];

// ─── Numeric helpers ──────────────────────────────────────────────────────────

function toCents(n){return Math.max(0,Math.round(Number(n||0)*100));}
function fromCents(c){return Math.max(0,Math.round(Number(c||0))/100);}
function safeAddCash(a,d){const n=Number(a.cash||0)+Number(d||0);a.cash=(Number.isFinite(n)&&!Number.isNaN(n))?n:0;}

// ─── Exchange core ────────────────────────────────────────────────────────────

let FMI={ticker:'FMI',treasury:0,hourlyTaxAccrual:0};
const TICKER_STATE=new Map(), EOH=new Map();
let __lastHourRecorded=new Date().getHours();

function _ensureTickerState(sym,price){
  let s=TICKER_STATE.get(sym);
  if(!s){s={last_trade:price||1,prev_close:price||1,day_volume:0,vwap_num:0,vwap_den:0,ema_last:price||1,flags:0};TICKER_STATE.set(sym,s);}
  return s;
}
function _rollHourIfNeeded(now=new Date()){
  const h=now.getHours(); if(h===__lastHourRecorded)return;
  __lastHourRecorded=h;
  const ts_hour=new Date(now.getFullYear(),now.getMonth(),now.getDate(),h,0,0,0).getTime();
  for(const c of companies){
    const s=_ensureTickerState(c.symbol,c.price);
    const vwap_h=s.vwap_den?(s.vwap_num/s.vwap_den):s.last_trade;
    const row={ts_hour,close:s.last_trade,prev_close:s.prev_close,hour_volume:s.day_volume,vwap_hour:vwap_h,fmi_tax_collected:FMI.hourlyTaxAccrual|0,flags:0};
    if(!EOH.has(c.symbol))EOH.set(c.symbol,[]);
    EOH.get(c.symbol).push(row);
    s.prev_close=s.last_trade; s.day_volume=0; s.vwap_num=0; s.vwap_den=0;
  }
  FMI.hourlyTaxAccrual=0;
}

// prevClose map for heatmap pct change
const prevClose = new Map(); // symbol -> price at last daily open

function resetDailyPrevClose() {
  for (const c of companies) {
    prevClose.set(c.symbol, c.price);
  }
}

// ─── Companies ────────────────────────────────────────────────────────────────

const COMPANY_NAMES=["Anchor Biotech","Anchor International","Anchor Realty","Anchor Retail","ApexContraband","AshenTextiles","Aspen Automation","Aspen Energy","Aspen Financial","Atlas Consulting","Atlas Dynamics","Atlas Energy","Atlas Realty","Atlas Supplies","Atlas Textiles","Aurora Electric","Aurora Enterprises","Aurora Metals","Aurora Robotics","Beacon Consulting","Beacon Technologies","BlackCapital","BloodWorks","Blue Media","Blue Packaging","Blue Shipping","BoneMarkets","BoneYards","CarrionFarms","Cascade Minerals","Cascade Pharma","Catalyst Insurance","Catalyst Packaging","Catalyst Pharma","Cedar Dynamics","Cedar Insurance","Cedar Networks","CipherHoldings","CoalitionMetals","Comet Foods","Comet Packaging","Copper Dynamics","Copper Industries","Copper Insurance","Copper Marine","CorpseSystems","Crescent Robotics","Crescent Ventures","CrimsonChains","DarkRobotics","East Consulting","East Foods","East Retail","East Ventures","Evergreen Financial","First Minerals","First Networks","First Works","Frontier Supplies","GhostFoundry","Global Enterprises","Global Supplies","Golden Aerospace","Golden Insurance","Golden Packaging","GraftBiotech","Granite Aerospace","Granite Realty","GraveWorks","Green Shipping","GreyMining","GreywaterLabs","Grove Enterprises","Harbor Enterprises","Harbor Financial","Harbor Media","HollowLogistics","Horizon Automation","Horizon Retail","Liberty Packaging","Liberty Ventures","Lighthouse Logistics","Lumen Shipping","Maple Industries","MireInsurance","Momentum Logistics","National Foods","National Media","National Packaging","National Retail","Neon Retail","Neon Technologies","Nexus Aerospace","Nexus Financial","Nexus Supplies","NightFinance","Nimbus Biotech","Nimbus Realty","NoirTransport","North Biotech","North Consulting","North Industries","North Motors","Nova Biotech","NullSyndicate","Oak Capital","Oak Marine","Oak Ventures","ObsidianShipping","OccultMaterials","OrganCorp","Orion Foods","Orion Logistics","Orion Supplies","PhantomCourier","Pioneer Aerospace","Pioneer Realty","Pioneer Supplies","Pixel Biotech","Pixel Dynamics","Pixel Software","Prairie Financial","Prime Automation","Redwood Materials","Redwood Retail","River Aerospace","River Materials","RogueMinerals","SableSecurity","SeverShipping","ShadePharma","ShadowDynamics","Sierra Aerospace","Sierra Apparel","Sierra Consulting","Sierra Hospitality","Silver Holdings","Silver Motors","Silver Shipping","Silver Works","SinisterFoods","Skyline Packaging","SmugglerIndustries","SmugglerMedia","SmugglerNetworks","South Consulting","South Hardware","South Industries","South Minerals","SpecterIndustries","Summit Automation","Summit Logistics","Summit Retail","Sycamore Partners","Sycamore Software","TempestArms","ToxicChains","UnderNet","United Hospitality","United Insurance","United Technologies","Valley Realty","VeinConsortium","Vertex Aerospace","Vertex Dynamics","Vertex Foods","Vertex Logistics","Vertex Robotics","Vertex Shipping","Vertex Systems","Vertex Ventures","West Hospitality","West Works","Willow Aerospace","Willow Hardware","Willow Labs","WraithEnergy","Zenith Automation","Zenith Health","Zenith Insurance","Zenith Media"];
const NAMES=Array.from(new Set(COMPANY_NAMES.map(n=>n.replace(/\d+$/,'').trim())));
function symbolize(name){const words=String(name||'').replace(/[^A-Za-z ]/g,' ').trim().split(/\s+/).filter(Boolean);let t=words.map(w=>w[0]).join('').toUpperCase();if(t.length<3){const letters=words.join('').toUpperCase();for(let i=1;i<letters.length&&t.length<3;i++)t+=letters[i];}if(t.length<3)t=(t+'FMK').slice(0,3);if(t.length>4)t=t.slice(0,4);return t;}
const companies=NAMES.map((n,i)=>({id:i,name:n,symbol:symbolize(n),price:rng(8,60),ohlc:[],lnP:0,sigma:0.03+seededRand()*0.04,mu:-0.0005+seededRand()*0.0015,kappa:0.04+seededRand()*0.08,sector:(i%8),offset:-0.3+seededRand()*0.6}));
(()=>{const used=new Set(),letters='ABCDEFGHIJKLMNOPQRSTUVWXYZ';for(const c of companies){let sym=c.symbol.replace(/[^A-Z]/g,'').slice(0,4);if(sym.length<3)sym=(sym+'FMKT').slice(0,3);let k=0;while(used.has(sym)){sym=k<26?sym.slice(0,3)+letters[k]:sym.slice(0,2)+letters[Math.floor((k-26)/26)%26]+letters[(k-26)%26];sym=sym.slice(0,4);k++;}c.symbol=sym;used.add(sym);}})();
const SECTORS=new Array(8).fill(0).map(()=>({lnIndex:Math.log(20+20*seededRand()),sigma:0.015+seededRand()*0.02,mu:-0.0002+seededRand()*0.0008}));
companies.forEach(c=>{c.lnP=Math.log(c.price);});

// ─── FLSH company (absurd dev valuation — Ƒ1,000,000,000/share) ─────────────────
// _special:true — excluded from GBM tick. Price drifts via its own slow random walk.
const FLSH_COMPANY = {
  id: 9999, name: 'FLSH Capital', symbol: 'FLSH',
  price: 1_000_000_000, lnP: Math.log(1_000_000_000),
  sigma: 0.0008, mu: 0.00002,
  ohlc: [], _special: true
};
companies.push(FLSH_COMPANY);

function updateFLSHPrice() {
  // FLSH runs its own slow random walk, completely decoupled from sector mean-reversion.
  // Volatility: tiny per-tick drift (±0.08% 1σ) + rare 1% shock (1% chance/tick)
  const f = FLSH_COMPANY;
  const eps = randn() * f.sigma;           // normal daily micro-drift
  f.lnP += f.mu + eps;
  if (Math.random() < 0.01) {              // rare ±1% shock
    f.lnP += randn() * 0.01;
  }
  // Hard floor at Ƒ500M — it will never crash to zero
  f.lnP = Math.max(Math.log(500_000_000), f.lnP);
  const prev = f.price;
  f.price = Math.exp(f.lnP);
  const now = Date.now();
  const open=prev, close=f.price;
  const high=Math.max(open,close)*(1+Math.abs(randn()*0.0002));
  const low =Math.min(open,close)*(1-Math.abs(randn()*0.0002));
  if (!Array.isArray(f.ohlc)) f.ohlc=[];
  f.ohlc.push({t:now,o:open,h:high,l:low,c:close,v:0});
  if (f.ohlc.length>400) f.ohlc.shift();
}

// ─── Market state restore ─────────────────────────────────────────────────────

const headlines=[];
function restoreMarketState(){
  const data=loadMarketState(); if(!data)return;
  if(Array.isArray(data.companies)){
    // Build a symbol->company map for safe restore (index-based restore breaks when company list changes)
    const symMap = new Map(companies.map(c=>[c.symbol,c]));
    for(const s of data.companies){
      if(!s||!s.symbol) continue;
      const c = symMap.get(s.symbol);
      if(!c) continue;
      if(typeof s.price==='number') c.price=s.price;
      if(typeof s.lnP  ==='number') c.lnP  =s.lnP;
      if(typeof s.sigma==='number') c.sigma=s.sigma;
      if(Array.isArray(s.ohlc))    c.ohlc =s.ohlc;
    }
  }
  if(Array.isArray(data.headlines))headlines.push(...data.headlines.slice(-200));
  console.log('[Market] State restored');
}
restoreMarketState();
resetDailyPrevClose();

// ─── v5.0: Limit Orders ───────────────────────────────────────────────────────
// Map: playerId -> Array<{id, side, symbol, qty, limitPrice, reservedCash, ts}>
const limitOrders = new Map();
const ORDER_EXPIRY_MS = 24 * 60 * 60 * 1000;

function getPlayerOrders(playerId) {
  if (!limitOrders.has(playerId)) limitOrders.set(playerId, []);
  return limitOrders.get(playerId);
}

function processLimitOrders() {
  const now = Date.now();
  for (const [playerId, orders] of limitOrders) {
    if (!orders.length) continue;
    const actor = getPlayer(playerId); if (!actor) continue;
    let changed = false;
    const filled = [];
    const expired = [];

    for (let i = orders.length - 1; i >= 0; i--) {
      const o = orders[i];
      // Expire old orders
      if (now - o.ts > ORDER_EXPIRY_MS) {
        // Refund reserved cash for buy orders
        if (o.side === 'buy' && o.reservedCash > 0) {
          safeAddCash(actor, o.reservedCash);
        }
        expired.push(o.id);
        orders.splice(i, 1);
        changed = true;
        continue;
      }
      const c = companies.find(x => x.symbol === o.symbol);
      if (!c) continue;
      let fill = false;
      if (o.side === 'buy'  && c.price <= o.limitPrice) fill = true;
      if (o.side === 'sell' && c.price >= o.limitPrice) fill = true;
      if (!fill) continue;

      const fillPrice = c.price;
      if (o.side === 'buy') {
        const costC = toCents(fillPrice) * o.qty;
        const taxC  = Math.floor(costC * TRADE_TAX_BPS / 10000);
        const totalC = costC + taxC;
        const total  = fromCents(totalC);
        // reserved cash covers the limit price; refund the difference
        const refund = Math.max(0, o.reservedCash - total);
        if (refund > 0) safeAddCash(actor, refund);
        actor.holdings = actor.holdings || {};
        actor.holdings[o.symbol] = (actor.holdings[o.symbol] || 0) + o.qty;
        actor.basisC = actor.basisC || {};
        actor.basisC[o.symbol] = (actor.basisC[o.symbol] || 0) + costC;
        actor.xp += 3;
        FMI.treasury += (taxC / 100); FMI.hourlyTaxAccrual += (taxC / 100);
        try { addFundCash('FLSH', fromCents(costC) * FLSH_TRADE_PCT); } catch(_) {}
        broadcastTradeFeed({ side: 'buy', symbol: o.symbol, qty: o.qty, price: fillPrice, isLimit: true });
      } else {
        const have = actor.holdings ? (actor.holdings[o.symbol] || 0) : 0;
        const sellQty = Math.min(o.qty, have + Math.abs(Math.min(0, have)));
        if (sellQty > 0) {
          actor.holdings[o.symbol] = have - sellQty;
          if (actor.holdings[o.symbol] === 0) delete actor.holdings[o.symbol];
          const grossC = toCents(fillPrice) * sellQty;
          const taxC   = Math.floor(grossC * TRADE_TAX_BPS / 10000);
          safeAddCash(actor, fromCents(grossC - taxC));
          FMI.treasury += (taxC / 100); FMI.hourlyTaxAccrual += (taxC / 100);
          try { addFundCash('FLSH', fromCents(grossC) * FLSH_TRADE_PCT); } catch(_) {}
          const bB = Math.max(0, Number(actor.basisC?.[o.symbol] || 0));
          const avgC = have > 0 ? Math.floor(bB / have) : 0;
          actor.basisC = actor.basisC || {};
          actor.basisC[o.symbol] = Math.max(0, bB - Math.min(bB, avgC * sellQty));
          if ((actor.holdings[o.symbol] || 0) <= 0) { delete actor.holdings[o.symbol]; delete actor.basisC[o.symbol]; }
          broadcastTradeFeed({ side: 'sell', symbol: o.symbol, qty: sellQty, price: fillPrice, isLimit: true });
        }
      }

      filled.push({ orderId: o.id, side: o.side, symbol: o.symbol, qty: o.qty, fillPrice, limitPrice: o.limitPrice });
      orders.splice(i, 1);
      changed = true;
    }

    if (changed) {
      actor.level = calcLevel(actor.xp);
      savePlayer(actor);
      try {
        const equity = Object.entries(actor.holdings || {}).reduce((acc,[sym,qty])=>{const co=companies.find(x=>x.symbol===sym);return acc+(co?co.price*qty:0);},0);
        recordNetWorth(actor.id, actor.cash+equity, actor.cash, equity);
      } catch(e) {}
      for (const f of filled) {
        broadcastToPlayer(playerId, { type: 'limit_filled', data: f });
        }
      broadcastToPlayer(playerId, { type: 'orders', data: getPlayerOrders(playerId) });
      broadcastToPlayer(playerId, { type: 'portfolio', data: snapshotPortfolio(actor) });
    }
  }
}

// ─── v5.0: Active IPO state ────────────────────────────────────────────────────
let activeIPO = null; // { symbol, name, marketPrice, discountPrice, deadline, applied: Set<playerId> }

function runIPOEvent() {
  // Pick a random non-special company
  const eligible = companies.filter(c => !c._special && c.price > 5);
  if (!eligible.length) return;
  const c = eligible[Math.floor(Math.random() * eligible.length)];
  const discount = 0.15 + Math.random() * 0.20; // 15–35% discount
  const discountPrice = Math.max(1, c.price * (1 - discount));
  const deadline = Date.now() + IPO_WINDOW_MS;

  activeIPO = { symbol: c.symbol, name: c.name, marketPrice: c.price, discountPrice, deadline, applied: new Set() };

  broadcast({ type: 'ipo', data: {
    symbol: c.symbol, name: c.name,
    marketPrice: c.price, discountPrice,
    deadline, maxShares: 100
  }});
  console.log(`[IPO] ${c.symbol} — market Ƒ${c.price.toFixed(2)}, IPO Ƒ${discountPrice.toFixed(2)}, window ${IPO_WINDOW_MS/1000}s`);

  setTimeout(() => {
    if (activeIPO && activeIPO.symbol === c.symbol) {
      broadcast({ type: 'ipo_expired', data: { symbol: c.symbol } });
      activeIPO = null;
    }
  }, IPO_WINDOW_MS);
}

// ─── v5.0: Earnings events ─────────────────────────────────────────────────────
function runEarningsEvent() {
  const eligible = companies.filter(c => !c._special);
  if (!eligible.length) return;
  const c = eligible[Math.floor(Math.random() * eligible.length)];
  const beat = Math.random() > 0.45;
  const magnitude = 0.06 + Math.random() * 0.14; // 6–20%
  if (beat) {
    c.lnP += magnitude;
  } else {
    c.lnP -= magnitude;
  }
  c.price = Math.max(0.5, Math.exp(c.lnP));
  const newPrice = c.price;

  const earningsMsg = {
    symbol: c.symbol, name: c.name,
    beat, magnitude: (magnitude * 100).toFixed(1),
    newPrice
  };

  // Broadcast global headline
  const dir = beat ? '▲' : '▼';
  const tone = beat ? 'good' : 'bad';
  pushHeadline(`EARNINGS: ${c.name} (${c.symbol}) ${beat ? 'beats' : 'misses'} — ${dir}${(magnitude*100).toFixed(1)}% @ Ƒ${newPrice.toFixed(2)}`, tone, c.symbol);

  // Notify holders specifically
  for (const [playerId, sockets] of playerSockets) {
    const actor = getPlayer(playerId); if (!actor) continue;
    const qty = (actor.holdings || {})[c.symbol];
    if (qty && qty !== 0) {
      broadcastToPlayer(playerId, { type: 'earnings_alert', data: earningsMsg });
    }
  }
}

// ─── XP / Level helpers (999-level scaling curve) ────────────────────────────
// XP required to advance FROM level n to level n+1 = floor(60 * 1.06^(n-1))
// Level 1→2: 60 XP | Level 10→11: ~107 | Level 50→51: ~1,038 | Level 999: astronomical
function xpToNextLevel(level) {
  return Math.floor(60 * Math.pow(1.06, Math.max(1, level) - 1));
}
function calcLevel(totalXp) {
  let xp = Math.max(0, totalXp || 0);
  let level = 1;
  while (level < 999) {
    const needed = xpToNextLevel(level);
    if (xp < needed) break;
    xp -= needed;
    level++;
  }
  return Math.min(999, level);
}
function xpForNextLevel(totalXp) {
  // Returns [xpIntoCurrentLevel, xpNeededForCurrentLevel]
  let xp = Math.max(0, totalXp || 0);
  let level = 1;
  while (level < 999) {
    const needed = xpToNextLevel(level);
    if (xp < needed) return [xp, needed];
    xp -= needed;
    level++;
  }
  return [0, xpToNextLevel(999)];
}

// ─── Galaxy: Per-colony faction dividend bonuses ──────────────────────────────
// Format: { colonyId: { factionId: { sectorIndex: extraDividendRate } } }
// These stack on top of DIVIDEND_RATE (0.6%). They apply when the player's
// faction is the dominant controller of that colony.
const COLONY_BONUSES = {
  new_anchor:       { coalition:{0:0.012,2:0.008,6:0.005}, syndicate:{0:0.004},        void:{6:0.005}          },
  cascade_station:  { coalition:{3:0.008,7:0.004},          syndicate:{3:0.006},        void:{3:0.003}          },
  frontier_outpost: { coalition:{5:0.008},                  syndicate:{5:0.006,7:0.004},void:{5:0.004}          },
  the_hollow:       { coalition:{7:0.003},                  syndicate:{7:0.015},        void:{7:0.006}          },
  vein_cluster:     { coalition:{1:0.004},                  syndicate:{1:0.012},        void:{1:0.015}          },
  aurora_prime:     { coalition:{6:0.010,4:0.008},          syndicate:{4:0.006},        void:{4:0.012,6:0.008}  },
  null_point:       { coalition:{},                         syndicate:{7:0.008},        void:{1:0.012,4:0.010}  },
};

// Build sector bonus map for a given player faction from current colony states
// Returns: { sectorIndex -> extraRate }
function buildFactionSectorBonus(playerFaction, colonyStates) {
  const sectorBonus = {};
  for (const colony of colonyStates) {
    if (!colony || !colony.id) continue;
    const bonusTable = COLONY_BONUSES[colony.id];
    if (!bonusTable || !bonusTable[playerFaction]) continue;
    // Check if this faction is the dominant controller of this colony
    const ctrl = {
      coalition: colony.control_coalition || 0,
      syndicate: colony.control_syndicate || 0,
      void:      colony.control_void      || 0,
    };
    // fleshstation colony is always controlled by fleshstation — no bonuses granted here
    if (colony.faction === 'fleshstation') continue;
    const leading = ['coalition','syndicate','void'].reduce((b,f)=>ctrl[f]>ctrl[b]?f:b,'coalition');
    if (leading !== playerFaction) continue;  // must be the leading faction

    const bonuses = bonusTable[playerFaction];
    for (const [sec, rate] of Object.entries(bonuses)) {
      const s = Number(sec);
      // Contested colonies give 50% of the bonus (more volatile)
      const effective = colony.contested ? rate * 0.5 : rate;
      sectorBonus[s] = (sectorBonus[s] || 0) + effective;
    }
  }
  return sectorBonus;
}

// ─── v5.0: Dividends (with faction colony bonuses) ────────────────────────────
function runDividends() {
  let totalPaid = 0;
  // Load colony states and player factions once (outside the player loop)
  let colonyStates = [];
  let playerFactions = {};
  try { colonyStates = getAllColonyStates(); } catch(_) {}
  try { playerFactions = getPlayerFactionsBulk(); } catch(_) {}

  for (const [playerId, sockets] of playerSockets) {
    if (!sockets.size) continue;
    const actor = getPlayer(playerId); if (!actor) continue;

    // Base dividends from DIVIDEND_SECTORS holdings
    let dividend = 0;
    const faction = playerFactions[playerId] || null;
    const sectorBonus = faction && faction !== 'fleshstation'
      ? buildFactionSectorBonus(faction, colonyStates)
      : {};

    for (const [sym, qty] of Object.entries(actor.holdings || {})) {
      if (!qty || qty <= 0) continue;
      const c = companies.find(x => x.symbol === sym);
      if (!c) continue;
      const s = c.sector;
      // Base dividend (Finance/Insurance/Energy/Tech)
      if (DIVIDEND_SECTORS.has(s)) {
        const baseRate = DIVIDEND_RATE + (sectorBonus[s] || 0);
        dividend += c.price * qty * baseRate;
      }
      // Faction-specific bonus sectors (Biotech=1, Manufacturing=3, Logistics=5, Misc=7)
      // that aren't in DIVIDEND_SECTORS but have colony bonuses
      else if (sectorBonus[s]) {
        dividend += c.price * qty * sectorBonus[s];
      }
    }
    if (dividend < 0.01) continue;
    dividend = Math.round(dividend * 100) / 100;
    safeAddCash(actor, dividend);
    actor.xp += 3;
    savePlayer(actor);
    totalPaid += dividend;

    // Record net worth after dividend payout
    try {
      const equity = Object.entries(actor.holdings||{}).reduce((acc,[sym,qty])=>{
        const co=companies.find(x=>x.symbol===sym); return acc+(co?co.price*qty:0);
      },0);
      recordNetWorth(actor.id, actor.cash+equity, actor.cash, equity);
    } catch(_) {}

    const bonusSectors = Object.keys(sectorBonus).length;
    const label = bonusSectors > 0 && faction
      ? `+Ƒ${dividend.toLocaleString()} dividend  ·  ${faction[0].toUpperCase()+faction.slice(1)} colony bonus active`
      : `+Ƒ${dividend.toLocaleString()} dividend`;
    broadcastToPlayer(playerId, { type: 'dividend', data: { amount: dividend, label } });
    broadcastToPlayer(playerId, { type: 'portfolio', data: snapshotPortfolio(actor) });
  }
  if (totalPaid > 0) console.log(`[Dividends] Paid Ƒ${totalPaid.toFixed(2)} total`);
}

// ─── v5.0: Short-sell borrow fees ─────────────────────────────────────────────
function runBorrowFees() {
  for (const [playerId, sockets] of playerSockets) {
    if (!sockets.size) continue;
    const actor = getPlayer(playerId); if (!actor) continue;
    let fee = 0;
    for (const [sym, qty] of Object.entries(actor.holdings || {})) {
      if (!qty || qty >= 0) continue; // only short positions (negative qty)
      const c = companies.find(x => x.symbol === sym);
      if (!c) continue;
      fee += c.price * Math.abs(qty) * BORROW_RATE;
    }
    if (fee < 0.01) continue;
    fee = Math.round(fee * 100) / 100;
    actor.cash = Math.max(0, actor.cash - fee);
    savePlayer(actor);
    try {
      const equity = Object.entries(actor.holdings||{}).reduce((acc,[sym,qty])=>{
        const co=companies.find(x=>x.symbol===sym); return acc+(co?co.price*qty:0);
      },0);
      recordNetWorth(actor.id, actor.cash+equity, actor.cash, equity);
    } catch(_) {}
    broadcastToPlayer(playerId, { type: 'borrow_fee', data: { amount: fee } });
    broadcastToPlayer(playerId, { type: 'portfolio', data: snapshotPortfolio(actor) });
  }
}

// ─── v5.0: Trade Feed ─────────────────────────────────────────────────────────
function broadcastTradeFeed({ side, symbol, qty, price, isLimit = false, isIPO = false }) {
  broadcast({
    type: 'trade_feed',
    data: { side, symbol, qty, price: Math.round(price * 100) / 100, isLimit, isIPO, ts: Date.now() }
  });
}



// ─── Express + WS ─────────────────────────────────────────────────────────────

const app=express();

// Guild eligibility: Patreon tier >= 2 OR dev/admin accounts
function isGuildEligible(player) {
  if (!player) return false;
  return (player.patreon_tier >= 2) || isOwnerAccount(player.id);
}
const server=http.createServer(app);
const wss=new WebSocketServer({server});

app.use('/api/patreon/webhook', express.raw({type:'application/json'}));
app.use(express.json());
app.use('/',express.static(path.join(__dirname,'..','client')));

// ─── REST: Auth ───────────────────────────────────────────────────────────────

app.post('/api/register',(req,res)=>{
  try{
    const {name,password}=req.body||{};
    if(!name||!name.trim()) return res.status(400).json({ok:false,error:'name_required'});
    if(!password||password.length<4) return res.status(400).json({ok:false,error:'password_too_short'});
    const trimmed=name.trim().slice(0,32);
    if(!isNameAvailable(trimmed)) return res.status(409).json({ok:false,error:'name_taken'});
    const id=uuidv4();
    const player=createPlayerSync(id,trimmed,password);
    res.json({ok:true,token:player.id,name:player.name,cash:player.cash,patreon_tier:0});
  }catch(e){console.error('/api/register:',e);res.status(500).json({ok:false,error:'server_error'});}
});

app.post('/api/login',(req,res)=>{
  try{
    const {name,password}=req.body||{};
    if(!name||!password) return res.status(400).json({ok:false,error:'missing_fields'});
    const player=getPlayerByName(name.trim());
    if(!player) return res.status(401).json({ok:false,error:'invalid_credentials'});
    if(!verifyPassword(password,player.password_hash,player.password_salt))
      return res.status(401).json({ok:false,error:'invalid_credentials'});
    touchPlayer(player.id);
    res.json({ok:true,token:player.id,name:player.name,cash:player.cash,xp:player.xp,level:player.level,title:player.title,patreon_tier:player.patreon_tier||0,is_dev:!!(isDevAccount(player.id)),is_admin:!!(isAdminAccount(player.id)),is_prime:!!(isOwnerAccount(player.id))});
  }catch(e){console.error('/api/login:',e);res.status(500).json({ok:false,error:'server_error'});}
});

app.get('/api/name_available',(req,res)=>{
  const name=String(req.query.name||'').trim();
  res.json({ok:true,available:isNameAvailable(name)});
});

app.get('/api/whoami',(req,res)=>{
  const tok=tokenFrom(req);
  const p=tok?getPlayer(tok):null;
  if(!p) return res.status(404).json({ok:false,error:'not_found'});
  res.json({ok:true,id:p.id,name:p.name,cash:p.cash,holdings:p.holdings,xp:p.xp,level:p.level,title:p.title,patreon_tier:p.patreon_tier||0,is_dev:!!(isDevAccount(p.id)),is_admin:!!(isAdminAccount(p.id)),is_dunced:!!(isDunced(p.id)),is_prime:!!(isOwnerAccount(p.id))});
});

app.post('/api/rename',(req,res)=>{
  try{
    const tok=tokenFrom(req);
    const p=tok?getPlayer(tok):null;
    if(!p) return res.status(401).json({ok:false,error:'unauthorized'});
    const name=String(req.body?.name||req.query.name||'').trim().slice(0,32);
    if(!name) return res.status(400).json({ok:false,error:'invalid_name'});
    if(!isNameAvailable(name)) return res.status(409).json({ok:false,error:'name_taken'});
    renamePlayer(p.id,name);
    res.json({ok:true,name});
  }catch(e){res.status(500).json({ok:false,error:String(e)});}
});

app.post('/api/patreon/link',(req,res)=>{
  try{
    const tok=tokenFrom(req);
    const p=tok?getPlayer(tok):null;
    if(!p) return res.status(401).json({ok:false,error:'unauthorized'});
    const email=String(req.body?.email||'').trim().toLowerCase();
    if(!email||!email.includes('@')) return res.status(400).json({ok:false,error:'invalid_email'});
    linkPatreonEmail(p.id,email);
    res.json({ok:true,message:'Patreon email linked.'});
  }catch(e){res.status(500).json({ok:false,error:String(e)});}
});

app.get('/api/pnl/:token',(req,res)=>{
  try{
    const p=getPlayer(req.params.token);
    if(!p) return res.status(404).json({ok:false,error:'not_found'});
    res.json({ok:true,history:getNetWorthHistory(p.id,300)});
  }catch(e){res.status(500).json({ok:false,error:String(e)});}
});

// ─── REST: Patreon Webhook ────────────────────────────────────────────────────

const PATREON_TIER_MAP = { 500:1, 2500:2, 10000:3 };

function parseTierFromPatreon(data) {
  try {
    const cents = data?.attributes?.amount_cents || data?.attributes?.currently_entitled_amount_cents || 0;
    if (cents >= 10000) return 3;
    if (cents >= 2500)  return 2;
    if (cents >= 500)   return 1;
  } catch(e) {}
  return 0;
}

app.post('/api/patreon/webhook', async (req, res) => {
  try {
    if (PATREON_WEBHOOK_SECRET) {
      const sig = req.headers['x-patreon-signature'];
      if (!sig) return res.status(401).json({ok:false,error:'missing_signature'});
      const expected = createHmac('md5', PATREON_WEBHOOK_SECRET).update(req.body).digest('hex');
      if (sig !== expected) return res.status(401).json({ok:false,error:'invalid_signature'});
    }
    const body    = JSON.parse(req.body.toString());
    const event   = req.headers['x-patreon-event'];
    const member  = body?.data;
    const email   = body?.included?.find(i=>i.type==='user')?.attributes?.email || null;
    const memberId = member?.id || null;
    console.log(`[Patreon] Event: ${event}, member: ${memberId}, email: ${email}`);
    if (event === 'members:pledge:delete' || event === 'members:delete') {
      let player = memberId ? getPlayerByPatreonMemberId(memberId) : null;
      if (!player && email) player = getPlayerByPatreonEmail(email);
      if (player) {
        setPatreonTier(player.id, 0, null, null);
        broadcastToPlayer(player.id, {type:'patreon', data:{tier:0,message:'Your Patreon membership has ended.'}});
      }
      return res.json({ok:true});
    }
    if (event === 'members:pledge:create' || event === 'members:pledge:update' || event === 'members:create' || event === 'members:update') {
      const tier = parseTierFromPatreon(member);
      if (!tier) return res.json({ok:true});
      if (tier === 3 && countCEOs() >= CEO_MAX) return res.status(409).json({ok:false,error:'ceo_slots_full'});
      const expiresAt = Date.now() + 40*24*60*60*1000; // 40 days — buffer for late Patreon billing
      let player = memberId ? getPlayerByPatreonMemberId(memberId) : null;
      if (!player && email) player = getPlayerByPatreonEmail(email);
      if (player) {
        setPatreonTier(player.id, tier, memberId, expiresAt);
        broadcastToPlayer(player.id, {type:'patreon', data:{tier, tierName:TIERS[tier]?.name, message:`Patreon tier activated: ${TIERS[tier]?.name}!`}});
        if (tier >= 2) { syncFundMembership(); broadcastFundUpdate(); }
      }
      return res.json({ok:true});
    }
    res.json({ok:true, note:'unhandled event'});
  } catch(e) {
    console.error('[Patreon webhook error]', e);
    res.status(500).json({ok:false,error:String(e)});
  }
});

// ─── Hedge Fund helpers ──────────────────────────────────────────────────────

function getFundNAV() {
  const cash     = getFundCash();
  const holdings = getFundHoldings();
  const equity   = holdings.reduce((acc, h) => {
    const c = companies.find(x => x.symbol === h.symbol);
    return acc + (c ? c.price * h.qty : 0);
  }, 0);
  return { cash, equity, nav: cash + equity, holdings };
}

function fundSnapshot() {
  const { cash, equity, nav, holdings } = getFundNAV();
  const totalShares = getTotalFundShares();
  const members     = getFundMembers();
  const pricePerShare = totalShares > 0 ? nav / totalShares : 1;
  return {
    nav, cash, equity, totalShares, pricePerShare,
    members: members.map(m => ({
      name:       m.name,
      shares:     m.shares,
      value:      m.shares * pricePerShare,
      pct:        totalShares > 0 ? (m.shares / totalShares * 100).toFixed(1) : '0.0',
      patreon_tier: m.patreon_tier,
    })),
    holdings: holdings.map(h => {
      const c = companies.find(x => x.symbol === h.symbol);
      return { symbol: h.symbol, qty: h.qty, price: c?.price || 0, value: (c?.price||0)*h.qty };
    }),
    proposals: getOpenProposals(),
    ledger:    getFundLedger(20),
  };
}

function broadcastFundUpdate() {
  const snap = fundSnapshot();
  const data = JSON.stringify({ type: 'fund_update', data: snap });
  const members = getFundMembers();
  for (const m of members) {
    const sockets = playerSockets.get(m.player_id);
    if (!sockets) continue;
    for (const ws of sockets) { try { if(ws.readyState===1) ws.send(data); } catch(e){} }
  }
}

function processFundProposals() {
  expireOldProposals();
  const open = getOpenProposals();
  const memberCount = getFundMembers().length;
  const majority = Math.ceil(memberCount / 2);
  for (const prop of open) {
    const totalVotes = prop.votes_yes + prop.votes_no;
    const passed  = prop.votes_yes >= majority && prop.votes_yes > prop.votes_no;
    const failed  = prop.votes_no  >= majority;
    const timeout = prop.expires_at < Date.now();
    if (passed || failed || (timeout && totalVotes > 0)) {
      const status = passed ? 'passed' : 'rejected';
      resolveProposal(prop.id, status);
      if (passed) {
        const c = companies.find(x => x.symbol === prop.symbol);
        if (c) {
          const { cash } = getFundNAV();
          const holdings = getFundHoldings();
          const current  = holdings.find(h => h.symbol === prop.symbol);
          const haveQty  = current?.qty || 0;
          if (prop.side === 'buy') {
            const cost = c.price * prop.qty;
            if (cash >= cost) {
              setFundCash(cash - cost);
              setFundHolding(prop.symbol, haveQty + prop.qty);
              logFundTrade(prop.symbol, 'buy', prop.qty, c.price, `Vote passed ${prop.votes_yes}-${prop.votes_no}`);
              pushHeadline(`GUILD: Acquired ${prop.qty}x ${prop.symbol} @ Ƒ${c.price.toFixed(2)}`,'good', prop.symbol);
            }
          } else if (prop.side === 'sell') {
            const qty = Math.min(prop.qty, haveQty);
            if (qty > 0) {
              const proceeds = c.price * qty;
              setFundCash(cash + proceeds);
              setFundHolding(prop.symbol, haveQty - qty);
              logFundTrade(prop.symbol, 'sell', qty, c.price, `Vote passed ${prop.votes_yes}-${prop.votes_no}`);
              pushHeadline(`GUILD: Sold ${qty}x ${prop.symbol} @ Ƒ${c.price.toFixed(2)}`,'neutral', prop.symbol);
            }
          }
        }
      }
      broadcastFundUpdate();
    }
  }
}

// ─── REST: Market ─────────────────────────────────────────────────────────────

// ─── REST: Hedge Fund ────────────────────────────────────────────────────────

app.get('/api/fund/snapshot', (req, res) => {
  try {
    const tok = tokenFrom(req);
    const p   = tok ? getPlayer(tok) : null;
    const snap = fundSnapshot();
    snap.isMember    = p ? isFundMember(p.id) : false;
    snap.myShares    = p ? (getFundMember(p.id)?.shares || 0) : 0;
    snap.myValue     = snap.myShares * snap.pricePerShare;
    snap.canPropose  = p ? isGuildEligible(p) : false;
    snap.myVotes     = p ? (p.patreon_tier >= 3 ? 2 : 1) : 0;
    res.json({ ok: true, ...snap });
  } catch(e) { res.status(500).json({ ok: false, error: String(e) }); }
});

app.post('/api/fund/deposit', (req, res) => {
  try {
    const tok = tokenFrom(req);
    const p   = tok ? getPlayer(tok) : null;
    if (!p) return res.status(401).json({ ok: false, error: 'unauthorized' });
    if (!isGuildEligible(p)) return res.status(403).json({ ok: false, error: 'guild_members_only' });
    const amount = Math.max(1, Math.floor(Number(req.body?.amount) || 0));
    if (!amount) return res.status(400).json({ ok: false, error: 'invalid_amount' });
    syncFundMembership();
    const { nav } = getFundNAV();
    const newShares = depositToFundFn(p.id, amount, nav);
    broadcastFundUpdate();
    res.json({ ok: true, newShares, nav });
  } catch(e) { res.status(400).json({ ok: false, error: String(e) }); }
});

app.post('/api/fund/withdraw', (req, res) => {
  try {
    const tok = tokenFrom(req);
    const p   = tok ? getPlayer(tok) : null;
    if (!p) return res.status(401).json({ ok: false, error: 'unauthorized' });
    const pct = Math.min(1, Math.max(0.01, Number(req.body?.pct) || 0));
    const { nav } = getFundNAV();
    const cashOut = withdrawFromFundFn(p.id, pct, nav);
    broadcastFundUpdate();
    res.json({ ok: true, cashOut });
  } catch(e) { res.status(400).json({ ok: false, error: String(e) }); }
});

app.post('/api/fund/propose', (req, res) => {
  try {
    const tok = tokenFrom(req);
    const p   = tok ? getPlayer(tok) : null;
    if (!p || !isGuildEligible(p)) return res.status(403).json({ ok: false, error: 'guild_members_only' });
    if (!isFundMember(p.id)) return res.status(403).json({ ok: false, error: 'not_a_member' });
    const { side, symbol, qty, reason } = req.body || {};
    if (!['buy','sell'].includes(side)) return res.status(400).json({ ok: false, error: 'invalid_side' });
    const sym = String(symbol||'').toUpperCase();
    const c   = companies.find(x => x.symbol === sym);
    if (!c) return res.status(400).json({ ok: false, error: 'unknown_symbol' });
    const q = Math.max(1, Math.min(100000, Math.floor(Number(qty)||0)));
    const id = createProposal(p.id, side, sym, q, String(reason||'').slice(0, 200));
    broadcastFundUpdate();
    pushHeadline(`GUILD: ${p.name} proposes to ${side} ${q}× ${sym}`, 'neutral', sym);
    res.json({ ok: true, proposalId: id });
  } catch(e) { res.status(400).json({ ok: false, error: String(e) }); }
});

app.post('/api/fund/vote', (req, res) => {
  try {
    const tok = tokenFrom(req);
    const p   = tok ? getPlayer(tok) : null;
    if (!p || !isGuildEligible(p)) return res.status(403).json({ ok: false, error: 'guild_members_only' });
    if (!isFundMember(p.id)) return res.status(403).json({ ok: false, error: 'not_a_member' });
    const { proposalId, vote } = req.body || {};
    if (!['yes','no'].includes(vote)) return res.status(400).json({ ok: false, error: 'invalid_vote' });
    if (hasVoted(proposalId, p.id)) return res.status(409).json({ ok: false, error: 'already_voted' });
    const weight = p.patreon_tier >= 3 ? 2 : 1;
    const updated = castVote(proposalId, p.id, vote, weight);
    processFundProposals();
    broadcastFundUpdate();
    res.json({ ok: true, proposal: updated });
  } catch(e) { res.status(400).json({ ok: false, error: String(e) }); }
});

// ─── REST: Player Funds ──────────────────────────────────────────────────────

function buildPriceMap() {
  const m = {};
  for (const c of companies) m[c.symbol] = c.price;
  return m;
}

function fundDetailSnapshot(fundId, playerId) {
  const fund       = getFund(fundId); if (!fund) return null;
  const priceMap   = buildPriceMap();
  const cash       = fund.cash;
  const portfolio  = getFundPortfolio(fundId);
  const equity     = portfolio.reduce((acc,h)=>acc+(priceMap[h.symbol]||0)*h.qty, 0);
  const nav        = cash + equity;
  const totalShares= getTotalFundSharesById(fundId);
  const spp        = totalShares > 0 ? nav / totalShares : 1;
  const members    = getFundMemberships(fundId);
  const myMember   = playerId ? members.find(m=>m.player_id===playerId) : null;
  return {
    id: fund.id, name: fund.name, type: fund.type,
    description: fund.description,
    nav, cash, equity, totalShares, spp,
    maxMembers: fund.max_members,
    memberCount: members.length,
    savingsRate: fund.savings_rate,
    members: members.map(m=>({
      name:m.name, shares:m.shares, value:m.shares*spp,
      pct: totalShares>0?(m.shares/totalShares*100).toFixed(1):'0.0',
      patreon_tier:m.patreon_tier,
      isOwner: m.player_id === fund.owner_id,
    })),
    holdings: portfolio.map(h=>{
      const c=companies.find(x=>x.symbol===h.symbol);
      return {symbol:h.symbol,qty:h.qty,price:c?.price||0,value:(c?.price||0)*h.qty};
    }),
    activity: getFundActivity(fundId, 20),
    isMember:  playerId ? isInFund(fundId, playerId) : false,
    myShares:  myMember?.shares || 0,
    myValue:   (myMember?.shares||0) * spp,
    isOwner:   fund.owner_id === playerId,
  };
}

app.get('/api/funds', (req, res) => {
  try {
    const tok   = tokenFrom(req);
    const actor = tok ? getPlayer(tok) : null;
    const isDev = actor ? isDevAccount(actor.id) : false;
    const priceMap = buildPriceMap();
    const funds = getAllFunds().map(f => {
      const portfolio  = getFundPortfolio(f.id);
      const equity     = portfolio.reduce((acc,h)=>acc+(priceMap[h.symbol]||0)*h.qty,0);
      const nav        = f.cash + equity;
      const isMember   = actor ? isInFund(f.id, actor.id) : false;
      // locked = visible but not interactable
      const locked =
        (f.type === 'flsh'    && !isDev) ||
        (f.type === 'patreon' && !(actor && isGuildEligible(actor)));
      return {
        id: f.id, name: f.name, type: f.type,
        description: f.description,
        nav, memberCount: getFundMemberCount(f.id),
        maxMembers: f.max_members,
        isMember, locked,
        savingsRate: f.savings_rate,
      };
    });
    res.json({ ok: true, funds });
  } catch(e) { res.status(500).json({ ok:false, error:String(e) }); }
});

app.get('/api/funds/:id', (req, res) => {
  try {
    const tok   = tokenFrom(req);
    const actor = tok ? getPlayer(tok) : null;
    const fund  = getFund(req.params.id);
    if (!fund) return res.status(404).json({ ok:false, error:'not_found' });
    const flshLocked    = fund.type==='flsh'    && (!actor || !isDevAccount(actor.id));
    const patreonLocked = fund.type==='patreon' && (!actor || !isGuildEligible(actor));
    if (patreonLocked) {
      // Return a public-facing view — stats visible, actions locked
      const priceMap2 = buildPriceMap();
      const portfolio2 = getFundPortfolio(fund.id);
      const equity2   = portfolio2.reduce((acc,h)=>acc+(priceMap2[h.symbol]||0)*h.qty,0);
      const nav2      = fund.cash + equity2;
      return res.json({ ok:true, fund: {
        id:fund.id, name:fund.name, type:fund.type, description:fund.description,
        nav:nav2, cash:fund.cash, memberCount:getFundMemberCount(fund.id),
        maxMembers:fund.max_members, savingsRate:fund.savings_rate,
        locked:true, isMember:false, isOwner:false,
        members:[], holdings:[], activity:[],
      }});
    }
    if (flshLocked) {
      const priceMap2 = buildPriceMap();
      const portfolio2 = getFundPortfolio(fund.id);
      const equity2   = portfolio2.reduce((acc,h)=>acc+(priceMap2[h.symbol]||0)*h.qty,0);
      const nav2      = fund.cash + equity2;
      return res.json({ ok:true, fund: {
        id:fund.id, name:fund.name, type:fund.type, description:fund.description,
        nav:nav2, cash:fund.cash, memberCount:getFundMemberCount(fund.id),
        maxMembers:fund.max_members, savingsRate:fund.savings_rate,
        locked:true, isMember:false, isOwner:false,
        members:[], holdings:[], activity:[],
      }});
    }
    if (fund.type==='patreon' && actor && isGuildEligible(actor) && !isInFund(fund.id, actor.id)) {
      try { joinFund(fund.id, actor.id); } catch(_) {}
    }
    res.json({ ok:true, fund: fundDetailSnapshot(fund.id, actor?.id) });
  } catch(e) { res.status(500).json({ ok:false, error:String(e) }); }
});

app.post('/api/funds/create', (req, res) => {
  try {
    const tok   = tokenFrom(req);
    const actor = tok ? getPlayer(tok) : null;
    if (!actor) return res.status(401).json({ ok:false, error:'unauthorized' });
    if (actor.cash < FUND_CREATE_COST)
      return res.status(400).json({ ok:false, error:'insufficient_funds', need: FUND_CREATE_COST });
    const name = String(req.body?.name||'').trim().slice(0,40);
    if (!name || name.length < 3) return res.status(400).json({ ok:false, error:'name_too_short' });
    if (getFundByName(name)) return res.status(409).json({ ok:false, error:'name_taken' });
    const desc  = String(req.body?.description||'').slice(0,200);
    const id    = 'F_' + Math.random().toString(36).slice(2,10).toUpperCase();
    { const p = getPlayer(actor.id); p.cash -= FUND_CREATE_COST; savePlayerFn(p); }
    createFund(id, name, actor.id, desc, FUND_BASE_SLOTS);
    addFundCash(id, FUND_CREATE_COST * 0.1);
    logFundActivity(id,'create',actor.id,null,null,null,FUND_CREATE_COST,`Fund created by ${actor.name}`);
    pushHeadline(`${actor.name} launched hedge fund "${name}"`, 'good', null);
    res.json({ ok:true, fundId: id });
  } catch(e) { res.status(500).json({ ok:false, error:String(e) }); }
});

app.post('/api/funds/:id/buy-slots', (req, res) => {
  try {
    const tok   = tokenFrom(req);
    const actor = tok ? getPlayer(tok) : null;
    if (!actor) return res.status(401).json({ ok:false, error:'unauthorized' });
    const fund  = getFund(req.params.id);
    if (!fund) return res.status(404).json({ ok:false, error:'not_found' });
    if (fund.owner_id !== actor.id) return res.status(403).json({ ok:false, error:'not_owner' });
    const count = Math.max(1, Math.min(10, parseInt(req.body?.count)||1));
    const cost  = count * FUND_SLOT_COST;
    const p     = getPlayer(actor.id);
    if (p.cash < cost) return res.status(400).json({ ok:false, error:'insufficient_funds', need:cost });
    p.cash -= cost;
    savePlayerFn(p);
    addFundSlots(fund.id, count);
    logFundActivity(fund.id,'slot_purchase',actor.id,null,null,null,cost,`${count} slot(s) purchased`);
    // Sync player cash to client
    try {
      const equity = Object.entries(p.holdings||{}).reduce((acc,[sym,qty])=>{
        const co=companies.find(x=>x.symbol===sym); return acc+(co?co.price*qty:0);
      },0);
      recordNetWorth(p.id, p.cash+equity, p.cash, equity);
      broadcastToPlayer(p.id, { type:'portfolio', data: snapshotPortfolio(p) });
    } catch(_) {}
    res.json({ ok:true, newMax: fund.max_members + count });
  } catch(e) { res.status(500).json({ ok:false, error:String(e) }); }
});

app.post('/api/funds/:id/join', (req, res) => {
  try {
    const tok   = tokenFrom(req);
    const actor = tok ? getPlayer(tok) : null;
    if (!actor) return res.status(401).json({ ok:false, error:'unauthorized' });
    const fund = getFund(req.params.id);
    if (!fund) return res.status(404).json({ ok:false, error:'not_found' });
    if (fund.type==='flsh') return res.status(403).json({ ok:false, error:'dev_only' });
    if (fund.type==='patreon') return res.status(403).json({ ok:false, error:'patreon_only' });
    joinFund(fund.id, actor.id);
    logFundActivity(fund.id,'join',actor.id,null,null,null,null,`${actor.name} joined`);
    res.json({ ok:true });
  } catch(e) { res.status(400).json({ ok:false, error:String(e) }); }
});

app.post('/api/funds/:id/deposit', (req, res) => {
  try {
    const tok   = tokenFrom(req);
    const actor = tok ? getPlayer(tok) : null;
    if (!actor) return res.status(401).json({ ok:false, error:'unauthorized' });
    const fund  = getFund(req.params.id);
    if (!fund) return res.status(404).json({ ok:false, error:'not_found' });
    if (fund.type==='flsh' && !isDevAccount(actor.id)) return res.status(403).json({ ok:false, error:'dev_only' });
    const amount = Math.max(1, Math.floor(Number(req.body?.amount)||0));
    const shares = fundDepositFn(fund.id, actor.id, amount);
    const snap   = fundDetailSnapshot(fund.id, actor.id);
    broadcastToFundMembers(fund.id, { type:'fund_update', data:{ fundId:fund.id, ...snap }});
    // Refresh depositor's portfolio (cash decreased)
    try {
      const fresh = getPlayer(actor.id);
      if (fresh) broadcastToPlayer(actor.id, { type:'portfolio', data: snapshotPortfolio(fresh) });
    } catch(_) {}
    res.json({ ok:true, shares, nav: snap.nav });
  } catch(e) { res.status(400).json({ ok:false, error:String(e) }); }
});

app.post('/api/funds/:id/withdraw', (req, res) => {
  try {
    const tok   = tokenFrom(req);
    const actor = tok ? getPlayer(tok) : null;
    if (!actor) return res.status(401).json({ ok:false, error:'unauthorized' });
    const fund  = getFund(req.params.id);
    if (!fund) return res.status(404).json({ ok:false, error:'not_found' });
    const pct = Math.min(1, Math.max(0.01, Number(req.body?.pct)||0));
    const priceMap = buildPriceMap();
    const nav = getFundNAVById(fund.id, priceMap);
    const cashOut = fundWithdrawFn(fund.id, actor.id, pct, nav);
    const snap    = fundDetailSnapshot(fund.id, actor.id);
    broadcastToFundMembers(fund.id, { type:'fund_update', data:{ fundId:fund.id, ...snap }});
    // Refresh withdrawer's portfolio (cash increased)
    try {
      const fresh = getPlayer(actor.id);
      if (fresh) broadcastToPlayer(actor.id, { type:'portfolio', data: snapshotPortfolio(fresh) });
    } catch(_) {}
    res.json({ ok:true, cashOut });
  } catch(e) { res.status(400).json({ ok:false, error:String(e) }); }
});

app.post('/api/funds/:id/trade', (req, res) => {
  try {
    const tok   = tokenFrom(req);
    const actor = tok ? getPlayer(tok) : null;
    if (!actor) return res.status(401).json({ ok:false, error:'unauthorized' });
    const fund  = getFund(req.params.id);
    if (!fund) return res.status(404).json({ ok:false, error:'not_found' });
    if (fund.type==='player'  && fund.owner_id !== actor.id) return res.status(403).json({ ok:false, error:'owner_only' });
    if (fund.type==='flsh'    && !isDevAccount(actor.id))    return res.status(403).json({ ok:false, error:'dev_only' });
    if (fund.type==='patreon' && !isGuildEligible(actor))   return res.status(403).json({ ok:false, error:'guild_only' });
    const { side, symbol, qty } = req.body || {};
    if (!['buy','sell'].includes(side)) return res.status(400).json({ ok:false, error:'invalid_side' });
    const sym = String(symbol||'').toUpperCase();
    const c   = companies.find(x => x.symbol === sym && !x._special);
    if (!c) return res.status(400).json({ ok:false, error:'unknown_symbol' });
    const q   = Math.max(1, Math.floor(Number(qty)||0));
    const fundCash = fund.cash;
    const haveQty  = getFundPortfolio(fund.id).find(h=>h.symbol===sym)?.qty || 0;
    if (side==='buy') {
      const cost = c.price * q;
      if (fundCash < cost) return res.status(400).json({ ok:false, error:'insufficient_fund_cash', have:fundCash, need:cost });
      setFundCashById(fund.id, fundCash - cost);
      setFundPortfolioQty(fund.id, sym, haveQty + q);
      logFundActivity(fund.id,'trade_buy',actor.id,sym,q,c.price,cost,`Buy ${q}× ${sym} @ Ƒ${c.price.toFixed(2)}`);
      pushHeadline(`${fund.name}: bought ${q}× ${sym} @ Ƒ${c.price.toFixed(2)}`, 'good', sym);
    } else {
      const sellQty = Math.min(q, haveQty);
      if (sellQty <= 0) return res.status(400).json({ ok:false, error:'no_holdings' });
      const proceeds = c.price * sellQty;
      setFundCashById(fund.id, fundCash + proceeds);
      setFundPortfolioQty(fund.id, sym, haveQty - sellQty);
      logFundActivity(fund.id,'trade_sell',actor.id,sym,sellQty,c.price,proceeds,`Sell ${sellQty}× ${sym} @ Ƒ${c.price.toFixed(2)}`);
      pushHeadline(`${fund.name}: sold ${sellQty}× ${sym} @ Ƒ${c.price.toFixed(2)}`, 'neutral', sym);
    }
    if (fund.type==='flsh') updateFLSHPrice();
    const snap = fundDetailSnapshot(fund.id, actor.id);
    broadcastToFundMembers(fund.id, { type:'fund_update', data:{ fundId:fund.id, ...snap }});
    res.json({ ok:true, fund: snap });
  } catch(e) { res.status(500).json({ ok:false, error:String(e) }); }
});


// ─── REST: Galaxy Map ─────────────────────────────────────────────────────────

app.get('/api/galaxy/state', (req, res) => {
  try {
    const colonies = getAllColonyStates();
    res.json({ ok: true, colonies });
  } catch(e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/galaxy/join-faction', (req, res) => {
  try {
    const { token, factionId } = req.body || {};
    const p = token ? getPlayer(token) : null;
    if (!p) return res.status(401).json({ ok: false, error: 'not_logged_in' });
    if (factionId === 'fleshstation') return res.status(403).json({ ok: false, error: 'Flesh Station is dev-only.' });
    const VALID = ['coalition','syndicate','void'];
    if (!VALID.includes(factionId)) return res.status(400).json({ ok: false, error: 'invalid_faction' });
    const current = getPlayerFaction(p.id);
    if (current === factionId) return res.json({ ok: true, faction: factionId, message: 'Already aligned.' });
    setPlayerFaction(p.id, factionId);
    broadcastToPlayer(p.id, { type: 'faction_joined', data: { faction: factionId } });
    res.json({ ok: true, faction: factionId });
  } catch(e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/galaxy/fund', (req, res) => {
  try {
    const { token, colonyId, factionId, amount } = req.body || {};
    const p = token ? getPlayer(token) : null;
    if (!p) return res.status(401).json({ ok: false, error: 'not_logged_in' });
    const amt = Number(amount);
    if (!amt || amt < 1000) return res.status(400).json({ ok: false, error: 'min_1000' });
    if (p.cash < amt) return res.status(400).json({ ok: false, error: 'insufficient_funds' });
    const colony = getColonyState(colonyId);
    if (!colony) return res.status(404).json({ ok: false, error: 'colony_not_found' });
    const VALID = ['coalition','syndicate','void'];
    if (!VALID.includes(factionId)) return res.status(400).json({ ok: false, error: 'invalid_faction' });

    // Deduct cash
    p.cash = Math.round((p.cash - amt) * 100) / 100;
    savePlayer(p);

    // Record funding
    recordFactionFunding(p.id, colonyId, factionId, amt);

    // Adjust control %
    const boost = Math.min(12, Math.max(1, Math.round(amt / 80000)));
    const ctrl = {
      coalition: colony.control_coalition,
      syndicate: colony.control_syndicate,
      void:      colony.control_void,
    };
    ctrl[factionId] = Math.min(95, ctrl[factionId] + boost);
    const others = VALID.filter(f => f !== factionId);
    const half = Math.floor(boost / 2);
    others.forEach((f, i) => {
      ctrl[f] = Math.max(1, ctrl[f] - (i === 0 ? Math.ceil(boost/2) : half));
    });
    // Normalize to 100
    const total = ctrl.coalition + ctrl.syndicate + ctrl.void;
    if (total !== 100) {
      const diff = 100 - total;
      ctrl[factionId] = Math.min(99, ctrl[factionId] + diff);
    }

    // Update tension
    const newTension = Math.min(95, colony.tension + Math.round(boost * 1.8));
    const leading = VALID.reduce((best, f) => ctrl[f] > ctrl[best] ? f : best, 'coalition');
    const contested = ctrl[leading] < 60 ? 1 : 0;

    // Conquest timer logic
    let conquestFaction = colony.conquest_faction;
    let conquestTimer   = colony.conquest_timer;
    if (ctrl[leading] >= 75 && leading !== colony.faction) {
      if (!conquestTimer || conquestFaction !== leading) {
        conquestTimer   = Date.now() + 24 * 60 * 60 * 1000; // 24h
        conquestFaction = leading;
        console.log(`[Galaxy] Conquest timer started: ${leading} on ${colonyId}`);
      }
    } else {
      conquestTimer   = null;
      conquestFaction = null;
    }

    const newState = {
      control_coalition: ctrl.coalition,
      control_syndicate: ctrl.syndicate,
      control_void:      ctrl.void,
      tension:    newTension,
      contested,
      conquest_faction: conquestFaction || null,
      conquest_timer:   conquestTimer   || null,
    };
    updateColonyState(colonyId, newState);

    // Broadcast live update to all clients
    broadcast({
      type: 'colony_update',
      data: { colonyId, ...newState, war_chest: colony.war_chest + amt },
    });

    // Update player's portfolio so P&L reflects the cash deduction immediately
    try {
      const equity = Object.entries(p.holdings||{}).reduce((acc,[sym,qty])=>{
        const co = companies.find(x=>x.symbol===sym); return acc+(co?co.price*qty:0);
      },0);
      recordNetWorth(p.id, p.cash+equity, p.cash, equity);
      broadcastToPlayer(p.id, { type:'portfolio', data: snapshotPortfolio(p) });
    } catch(_) {}

    res.json({ ok: true, cash: p.cash, colonyId, factionId, boost, newControl: ctrl });
  } catch(e) {
    console.error('[Galaxy] fund error:', e);
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ─── Dunce: self-redeem (player pays 45% of net worth to escape) ──────────────
app.post('/api/dunce/redeem', (req, res) => {
  try {
    const { token } = req.body || {};
    const p = token ? getPlayer(token) : null;
    if (!p) return res.status(401).json({ ok: false, error: 'not_logged_in' });
    if (!isDunced(p.id)) return res.status(400).json({ ok: false, error: 'not_dunced' });

    const equity = Object.entries(p.holdings||{}).reduce((acc,[sym,qty])=>{
      const co = companies.find(x=>x.symbol===sym); return acc+(co?co.price*Math.abs(qty):0);
    },0);
    const netWorth = p.cash + equity;
    const fine = Math.round(netWorth * 0.45 * 100) / 100;

    if (p.cash < fine) {
      return res.status(400).json({ ok: false, error: 'insufficient_cash', fine, cash: p.cash,
        msg: `You need Ƒ${fine.toLocaleString(undefined,{maximumFractionDigits:2})} cash on hand (45% of net worth Ƒ${netWorth.toLocaleString(undefined,{maximumFractionDigits:2})}).` });
    }

    p.cash = Math.round((p.cash - fine) * 100) / 100;
    savePlayer(p);
    clearDunce(p.id);

    // Record net worth after fine
    try {
      recordNetWorth(p.id, p.cash + equity, p.cash, equity);
      broadcastToPlayer(p.id, { type: 'portfolio', data: snapshotPortfolio(p) });
    } catch(_) {}

    broadcastToPlayer(p.id, { type: 'undunced', data: { msg: `You paid Ƒ${fine.toLocaleString(undefined,{maximumFractionDigits:2})} and escaped the dunce corner.` } });
    broadcastToAdmins({ type: 'admin_log', data: { action: 'dunce_redeemed', player: p.name, fine } });
    broadcast({ type: 'chat', data: { id: Math.random().toString(36).slice(2), t: Date.now(), user: 'SYSTEM',
      text: `🎓 ${p.name} paid Ƒ${fine.toLocaleString(undefined,{maximumFractionDigits:2})} to escape the dunce corner.`, badge: '🎓', color: '#888', channel: 'global' } });

    res.json({ ok: true, fine, newCash: p.cash });
  } catch(e) {
    console.error('[Dunce] redeem error:', e);
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get('/health',(req,res)=>{res.json({status:'ok',uptime:process.uptime(),companies:companies.length,time:Date.now()});});

// ─── REST: Admin / Moderation ─────────────────────────────────────────────────

function requireAdmin(req, res, next) {
  const tok = tokenFrom(req);
  const p   = tok ? getPlayer(tok) : null;
  if (!p || !isAdminAccount(p.id)) return res.status(403).json({ ok: false, error: 'admin_only' });
  req.admin = p;
  next();
}

// Mute a player for N minutes (default 10)
app.post('/api/admin/mute', requireAdmin, (req, res) => {
  try {
    const { targetName, minutes = 10, reason = '' } = req.body || {};
    const target = getPlayerByName(String(targetName || '').trim());
    if (!target) return res.status(404).json({ ok: false, error: 'player_not_found' });
    const until = Date.now() + Math.max(1, Number(minutes)) * 60_000;
    setMute(target.id, until, req.admin.name, reason);
    broadcastToPlayer(target.id, { type: 'system_message', data: {
      text: `You have been muted for ${minutes} minute(s) by an admin. Reason: ${reason || 'none'}`,
      color: '#ff6b6b'
    }});
    // Notify all admins
    broadcastToAdmins({ type: 'admin_log', data: {
      action: 'mute', by: req.admin.name, target: target.name,
      minutes, reason, until
    }});
    res.json({ ok: true, target: target.name, mutedUntil: until });
  } catch(e) { res.status(500).json({ ok: false, error: String(e) }); }
});

// Unmute a player
app.post('/api/admin/unmute', requireAdmin, (req, res) => {
  try {
    const { targetName } = req.body || {};
    const target = getPlayerByName(String(targetName || '').trim());
    if (!target) return res.status(404).json({ ok: false, error: 'player_not_found' });
    clearMute(target.id);
    broadcastToPlayer(target.id, { type: 'system_message', data: {
      text: 'Your mute has been lifted by an admin.', color: '#51cf66'
    }});
    res.json({ ok: true, target: target.name });
  } catch(e) { res.status(500).json({ ok: false, error: String(e) }); }
});

// Timeout: disconnect a player's WebSocket session (they can reconnect)
app.post('/api/admin/timeout', requireAdmin, (req, res) => {
  try {
    const { targetName, reason = '' } = req.body || {};
    const target = getPlayerByName(String(targetName || '').trim());
    if (!target) return res.status(404).json({ ok: false, error: 'player_not_found' });
    const sockets = playerSockets.get(target.id);
    if (sockets && sockets.size > 0) {
      const msg = JSON.stringify({ type: 'kicked', data: {
        reason: reason || 'You have been timed out by an admin.'
      }});
      for (const ws of sockets) { try { ws.send(msg); ws.terminate(); } catch(_) {} }
    }
    broadcastToAdmins({ type: 'admin_log', data: {
      action: 'timeout', by: req.admin.name, target: target.name, reason
    }});
    res.json({ ok: true, target: target.name });
  } catch(e) { res.status(500).json({ ok: false, error: String(e) }); }
});

// Server-wide admin broadcast message
app.post('/api/admin/broadcast', requireAdmin, (req, res) => {
  try {
    const { text } = req.body || {};
    if (!text) return res.status(400).json({ ok: false, error: 'text_required' });
    broadcast({ type: 'admin_broadcast', data: {
      text: String(text).slice(0, 500),
      from: req.admin.name,
      t: Date.now()
    }});
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ ok: false, error: String(e) }); }
});

// View moderation record for a player
app.get('/api/admin/modlog/:name', requireAdmin, (req, res) => {
  try {
    const target = getPlayerByName(req.params.name);
    if (!target) return res.status(404).json({ ok: false, error: 'player_not_found' });
    const record = getModerationRecord(target.id);
    res.json({ ok: true, name: target.name, record: record || {} });
  } catch(e) { res.status(500).json({ ok: false, error: String(e) }); }
});

// List all currently online players (admin only)
app.get('/api/admin/online', requireAdmin, (req, res) => {
  try {
    const online = [];
    for (const [pid] of playerSockets) {
      const p = getPlayer(pid); if (!p) continue;
      online.push({ id: p.id, name: p.name, level: p.level, patreon_tier: p.patreon_tier });
    }
    res.json({ ok: true, online, count: online.length });
  } catch(e) { res.status(500).json({ ok: false, error: String(e) }); }
});

function broadcastToAdmins(msg) {
  const data = JSON.stringify(msg);
  for (const [pid] of playerSockets) {
    if (!isAdminAccount(pid)) continue;
    const sockets = playerSockets.get(pid);
    if (!sockets) continue;
    for (const ws of sockets) { try { if (ws.readyState === 1) ws.send(data); } catch(_) {} }
  }
}
app.get('/state',(req,res)=>{res.json({companies:companies.map(c=>({id:c.id,name:c.name,symbol:c.symbol,price:c.price})),headlines:headlines.slice(-30),time:Date.now()});});
app.post('/snapshot',(req,res)=>{saveMarketState(companies,headlines);res.json({saved:true});});
app.get('/api/v1/eoh/:ticker',(req,res)=>{const sym=String(req.params.ticker||'').toUpperCase();res.json(EOH.get(sym)||[]);});
app.get('/api/v1/fmi',(_req,res)=>{res.json({ticker:FMI.ticker,treasury:FMI.treasury});});

// ─── Helpers ──────────────────────────────────────────────────────────────────

function tokenFrom(req){
  const q=req.query?.token; if(q)return String(q);
  const auth=req.headers['authorization'];
  if(auth&&String(auth).toLowerCase().startsWith('bearer '))return String(auth).slice(7);
  return null;
}

function broadcast(msg){const data=JSON.stringify(msg);wss.clients.forEach(ws=>{if(ws.readyState===1)ws.send(data);});}

const playerSockets = new Map();
function broadcastToPlayer(playerId, msg) {
  const sockets = playerSockets.get(playerId);
  if (!sockets) return;
  const data = JSON.stringify(msg);
  for (const ws of sockets) { try { if(ws.readyState===1) ws.send(data); } catch(e){} }
}

function broadcastToFundMembers(fundId, msg) {
  try {
    const members = getFundMemberships(fundId);
    const data = JSON.stringify(msg);
    for (const m of members) {
      const sockets = playerSockets.get(m.player_id);
      if (!sockets) continue;
      for (const ws of sockets) { try { if(ws.readyState===1) ws.send(data); } catch(e){} }
    }
  } catch(e) {}
}

function pushHeadline(text,tone,symbol){
  const item={id:uuidv4(),t:Date.now(),text,tone,symbol};
  headlines.push(item); if(headlines.length>200)headlines.shift();
  broadcast({type:'news',data:item});
}

// ─── Headlines ────────────────────────────────────────────────────────────────

const THEMES_GOOD=['beats earnings expectations','announces dividend increase','opens new facility','expands into new market','signs multi-year contract','reports record user growth','launches new product line','receives safety certification','secures strategic partnership','approved for government grant','wins major infrastructure bid'];
const THEMES_BAD=['issues profit warning','faces regulatory probe','exec resignation rattles investors','data breach under investigation','suffers supply-chain disruption','product recall announced','union strike impacts operations','lawsuit filed by competitors','credit downgrade issued'];
const THEMES_WEIRD=['synthetic organ breakthrough','raided by maritime police','blackout from toxic spill','pirate tolls spike on key route','grey-market profits surge','smuggler network rumor denied','unexplained cargo manifest leak','enforcer contract renewed quietly','colony audit delayed indefinitely'];

function genHeadline(){
  const c=pick(companies),r=Math.random();
  const themes=r<0.45?THEMES_GOOD:(r<0.9?THEMES_BAD:THEMES_WEIRD);
  const tone=themes===THEMES_GOOD?'good':(themes===THEMES_BAD?'bad':'neutral');
  if(themes===THEMES_GOOD){c.lnP+=0.01+Math.random()*0.03;c.price=Math.max(0.5,Math.exp(c.lnP));}
  else if(themes===THEMES_BAD){c.lnP-=0.01+Math.random()*0.03;c.price=Math.max(0.5,Math.exp(c.lnP));}
  pushHeadline(`${c.name} (${c.symbol}): ${pick(themes)}`,tone,c.symbol);
}

// ─── Market sim ───────────────────────────────────────────────────────────────

function stepMarket(){
  _rollHourIfNeeded(new Date());
  const now=Date.now();

  // ── Sector index step with GARCH-style vol clustering ────────────────────
  for(let s=0;s<SECTORS.length;s++){
    const S=SECTORS[s];
    // Rare sector-wide shock (flash crash / rally)
    const sectorShock = Math.random()<0.002 ? randn()*0.08 : 0;
    const eps = randn()*S.sigma + sectorShock;
    S.lnIndex += S.mu + eps;
    // GARCH: vol spikes after big moves, decays slowly
    S.sigma = Math.max(0.005, Math.min(0.10, 0.88*S.sigma + 0.12*Math.abs(eps)));
  }

  companies.forEach(c=>{
    if (c._special) return;
    const S    = SECTORS[c.sector||0];
    const base = S.lnIndex + (c.offset||0);

    // Idiosyncratic shock — fat tails via Student-t approximation (mix of normals)
    const u    = Math.random();
    const tail = u < 0.03 ? 3.0 : (u < 0.08 ? 1.8 : 1.0);  // 3% heavy tail, 5% medium
    const eps  = randn() * (c.sigma||0.03) * tail;

    // Mean-reversion toward sector index (keeps stock in plausible range)
    c.lnP += (c.mu||0) + (c.kappa||0.06)*(base - c.lnP) + eps;

    // Vol clustering: sigma spikes after big moves, slowly mean-reverts to 0.03
    const absEps = Math.abs(eps);
    c.sigma = Math.max(0.008, Math.min(0.18,
      0.85*(c.sigma||0.03) + 0.10*absEps + 0.05*0.03
    ));

    // Rare idiosyncratic event: earnings miss/beat, acquisition rumour (0.3%/tick)
    if(Math.random()<0.003){
      const eventMag = 0.06 + Math.random()*0.18;  // 6–24% move
      c.lnP += (Math.random()<0.5?1:-1) * eventMag;
      c.sigma = Math.min(0.18, c.sigma * 2.5);     // vol spike after event
    }

    const prev=c.price;
    c.price=Math.max(0.50, Math.exp(c.lnP));

    // OHLC with realistic intrabar range proportional to vol
    const range = c.price * c.sigma * (0.5 + Math.random());
    const open=prev, close=c.price;
    const high=Math.max(open,close) + range*0.5;
    const low =Math.max(0.10, Math.min(open,close) - range*0.5);
    if(!Array.isArray(c.ohlc))c.ohlc=[];
    c.ohlc.push({t:now,o:open,h:high,l:low,c:close,v:0});
    if(c.ohlc.length>400)c.ohlc.shift();
  });

  updateFLSHPrice();
  processLimitOrders();

  // Build tick with pct change and sector
  const tickData = companies.map(c => {
    const pc = prevClose.get(c.symbol) || c.price;
    const pct = pc > 0 ? ((c.price - pc) / pc * 100) : 0;
    return { id: c.id, name: c.name, symbol: c.symbol, price: c.price, pct: Math.round(pct * 100) / 100, sector: c.sector };
  });
  broadcast({ type: 'tick', data: tickData });
  try { window?.__onPriceTickForModal?.(); } catch(_) {}
}

// ─── Portfolio snapshot ───────────────────────────────────────────────────────

function snapshotPortfolio(player){
  const holdings = player.holdings || {};
  const positions = Object.entries(holdings).filter(([,qty]) => qty !== 0).map(([sym, qty]) => {
    const c = companies.find(x => x.symbol === sym), px = c ? c.price : 0;
    const basisC = (player.basisC && player.basisC[sym]) || 0;
    const avg = qty > 0
      ? (basisC > 0 ? (basisC / qty) / 100 : 0)           // long: avg cost
      : (basisC < 0 ? Math.abs(basisC / qty) / 100 : 0);  // short: avg entry price
    const isShort = qty < 0;
    const val = px * Math.abs(qty) * (isShort ? -1 : 1);
    return { sym, qty, px, avg, val, isShort, sector: c?.sector ?? -1, sectorName: c ? (SECTOR_NAMES[c.sector] || 'Misc') : 'Unknown' };
  });
  const equity  = positions.filter(p => !p.isShort).reduce((a, p) => a + p.val, 0);
  const shortExposure = positions.filter(p => p.isShort).reduce((a, p) => a + Math.abs(p.val), 0);

  // Sector breakdown: { sectorName -> { value, pct } }
  const sectorMap = {};
  for (const pos of positions) {
    const sn = pos.sectorName;
    sectorMap[sn] = (sectorMap[sn] || 0) + Math.abs(pos.val);
  }

  const tier = TIERS[player.patreon_tier || 0];
  let playerFaction = null;
  try { playerFaction = getPlayerFaction(player.id); } catch(_) {}
  return {
    cash: player.cash, positions, equity, net: player.cash + equity,
    shortExposure, sectorBreakdown: sectorMap,
    xp: player.xp, level: player.level, title: player.title,
    patreon_tier: player.patreon_tier || 0,
    tierName: tier?.name || 'Free', badge: tier?.badge || null,
    chatColor: tier?.chatColor || null, transferFree: !tier?.transferFee,
    faction: playerFaction,
  };
}

// ─── Leaderboard ─────────────────────────────────────────────────────────────

function broadcastLeaderboard(){
  if(process.env.DISABLE_LEADERBOARD==='1')return;
  try{broadcast({type:'leaderboard',data:getLeaderboard(companies)});}catch(e){}
}

// ─── WebSocket ────────────────────────────────────────────────────────────────

const wsPlayers = new WeakMap();

wss.on('connection',(ws,req)=>{
  let player=null;
  try{
    const urlObj=new URL(req.url,`http://localhost:${PORT}`);
    const tok=urlObj.searchParams.get('token');
    if(tok)player=getPlayer(tok);
  }catch(e){}

  if(player){
    wsPlayers.set(ws,player.id);
    touchPlayer(player.id);
    if(!playerSockets.has(player.id))playerSockets.set(player.id,new Set());
    playerSockets.get(player.id).add(ws);
    ws.send(JSON.stringify({type:'hello',data:{playerId:player.id,name:player.name}}));
    ws.send(JSON.stringify({type:'welcome',data:{id:player.id,name:player.name,cash:player.cash,is_dunced:isDunced(player.id),dunce_reason:(()=>{try{return getDunceRecord(player.id)?.dunce_reason||'';}catch(_){return '';}})(),is_prime:!!(isOwnerAccount(player.id))}}));
    ws.send(JSON.stringify({type:'portfolio',data:snapshotPortfolio(player)}));
    // Send open limit orders on connect
    ws.send(JSON.stringify({type:'orders',data:getPlayerOrders(player.id)}));
    // Send active IPO if one is running
    if (activeIPO && activeIPO.deadline > Date.now()) {
      ws.send(JSON.stringify({type:'ipo',data:{
        symbol: activeIPO.symbol, name: activeIPO.name,
        marketPrice: activeIPO.marketPrice, discountPrice: activeIPO.discountPrice,
        deadline: activeIPO.deadline, maxShares: 100
      }}));
    }
    // Auto-enroll dev/admin accounts into guild on connect
    if (isDevAccount(player.id) || isAdminAccount(player.id)) {
      try { syncFundMembership(); } catch(_) {}
    }
  }else{
    ws.send(JSON.stringify({type:'welcome',data:{id:null,name:'Guest',cash:START_CASH}}));
  }

  ws.send(JSON.stringify({type:'init',data:{companies:companies.map(c=>({id:c.id,name:c.name,symbol:c.symbol,price:c.price,sector:c.sector})),headlines:headlines.slice(-30),leaderboard:getLeaderboard(companies)}}));

  ws.on('message',(buf)=>{
    let msg; try{msg=JSON.parse(buf.toString());}catch{return;}
    if(!msg||typeof msg!=='object')return;

    const playerId=wsPlayers.get(ws);
    const actor=playerId?getPlayer(playerId):null;

    if(msg.type==='ping'){if(actor)touchPlayer(actor.id);return;}

    if(!actor){
      if(msg.type==='chat'){
        const text=String(msg.text||'').slice(0,240);
        if(text)broadcast({type:'chat',data:{id:uuidv4(),t:Date.now(),user:'Guest',text,color:null,badge:null}});
      }
      return;
    }

    const tier=TIERS[actor.patreon_tier||0];

    // ── Market Order ─────────────────────────────────────────────────────────
    if(msg.type==='order'){
      const{side,symbol,shares}=msg;
      const s=String(symbol||'').toUpperCase(),qty=Math.max(1,Math.min(Number(shares)||0,MAX_SHARES));
      const c=companies.find(x=>x.symbol===s); if(!c||!qty)return;

      if(side==='buy'){
        const costC=toCents(c.price)*qty,taxC=Math.floor(costC*TRADE_TAX_BPS/10000),totalC=costC+taxC,total=fromCents(totalC);
        if(actor.cash>=total){
          safeAddCash(actor,-total);FMI.treasury+=(taxC/100);FMI.hourlyTaxAccrual+=(taxC/100);
          actor.holdings=actor.holdings||{};
          actor.holdings[s]=(actor.holdings[s]||0)+qty;
          actor.basisC=actor.basisC||{};actor.basisC[s]=(actor.basisC[s]||0)+costC;
          actor.xp += Math.max(3, Math.min(50, Math.floor(fromCents(costC) / 20)));
          try{addFundCash('FLSH', fromCents(costC)*FLSH_TRADE_PCT);}catch(_){}
          broadcastTradeFeed({side:'buy',symbol:s,qty,price:c.price});
                }
      } else if(side==='sell'){
        const have=actor.holdings?.[s]||0;
        if(have>=qty){
          actor.holdings[s]=have-qty;
          if(actor.holdings[s]<=0)delete actor.holdings[s];
          const grossC=toCents(c.price)*qty,taxC=Math.floor(grossC*TRADE_TAX_BPS/10000);
          safeAddCash(actor,fromCents(grossC-taxC));FMI.treasury+=(taxC/100);FMI.hourlyTaxAccrual+=(taxC/100);
          try{addFundCash('FLSH', fromCents(grossC)*FLSH_TRADE_PCT);}catch(_){}
          actor.basisC=actor.basisC||{};
          const bB=Math.max(0,Number(actor.basisC[s]||0)),avgC=have>0?Math.floor(bB/have):0;
          actor.basisC[s]=Math.max(0,bB-Math.min(bB,avgC*qty));
          if((actor.holdings[s]||0)<=0){delete actor.holdings[s];delete actor.basisC[s];}
          const _profitC = grossC - avgC*qty;
          actor.xp += 3 + (_profitC > 0 ? Math.min(100, Math.floor(fromCents(_profitC) / 10)) : 0);
          broadcastTradeFeed({side:'sell',symbol:s,qty,price:c.price});
            } else if(qty>0) {
          // SHORT SELL — sell more than owned
          const shortQty = qty - Math.max(0, have);
          const curShort = Math.abs(Math.min(0, have)); // existing short shares
          const newTotalShort = curShort + shortQty;

          // Guard: max short per symbol
          if (newTotalShort > MAX_SHORT_PER_SYM) {
            ws.send(JSON.stringify({type:'error',data:{msg:`Short cap exceeded. Max ${MAX_SHORT_PER_SYM} shares short per symbol.`}}));
            return;
          }
          // Guard: margin requirement — need 50% of short value in cash
          const shortValue = c.price * shortQty;
          const marginNeeded = shortValue * SHORT_MARGIN_RATE;
          if (actor.cash < marginNeeded) {
            ws.send(JSON.stringify({type:'error',data:{msg:`Insufficient margin. Need Ƒ${marginNeeded.toFixed(2)} collateral for this short.`}}));
            return;
          }
          // Clear long position first
          if(have>0){
            const grossC=toCents(c.price)*have,taxC=Math.floor(grossC*TRADE_TAX_BPS/10000);
            safeAddCash(actor,fromCents(grossC-taxC));FMI.treasury+=(taxC/100);
            actor.basisC=actor.basisC||{};delete actor.basisC[s];
          }
          // Enter short position
          actor.holdings=actor.holdings||{};
          actor.holdings[s]=(actor.holdings[s]||0) - shortQty;
          // Credit proceeds for shorted shares
          const shortGrossC=toCents(c.price)*shortQty,shortTaxC=Math.floor(shortGrossC*TRADE_TAX_BPS/10000);
          safeAddCash(actor,fromCents(shortGrossC-shortTaxC));FMI.treasury+=(shortTaxC/100);
          // Track avg short entry price in basisC (stored as negative to flag short)
          actor.basisC=actor.basisC||{};
          actor.basisC[s]=(actor.basisC[s]||0) - toCents(c.price)*shortQty;
          actor.xp+=3;
          broadcastTradeFeed({side:'sell',symbol:s,qty,price:c.price});
                }
      }

      actor.level=calcLevel(actor.xp);
      savePlayer(actor);
      try{
        const equity=Object.entries(actor.holdings||{}).reduce((acc,[sym,qty])=>{const co=companies.find(x=>x.symbol===sym);return acc+(co?co.price*Math.abs(qty):0);},0);
        recordNetWorth(actor.id,actor.cash+equity,actor.cash,equity);
      }catch(e){}


      ws.send(JSON.stringify({type:'portfolio',data:snapshotPortfolio(actor)}));
      broadcastLeaderboard();
    }

    // ── Limit Order ──────────────────────────────────────────────────────────
    if(msg.type==='limit_order'){
      const{side,symbol,shares,limitPrice}=msg;
      const s=String(symbol||'').toUpperCase();
      const qty=Math.max(1,Math.min(Number(shares)||0,MAX_SHARES));
      const lp=Math.max(0.01,Number(limitPrice)||0);
      const c=companies.find(x=>x.symbol===s); if(!c||!qty||!lp)return;

      let reservedCash = 0;
      if(side==='buy'){
        // Reserve cash upfront based on limit price
        const costC=toCents(lp)*qty,taxC=Math.floor(costC*TRADE_TAX_BPS/10000);
        reservedCash = fromCents(costC+taxC);
        if(actor.cash < reservedCash){
          ws.send(JSON.stringify({type:'error',data:{msg:'Insufficient cash to place limit buy order.'}}));
          return;
        }
        safeAddCash(actor, -reservedCash);
      }

      const order = {
        id: uuidv4(), side, symbol: s, qty, limitPrice: lp,
        reservedCash, ts: Date.now()
      };
      getPlayerOrders(playerId).push(order);
      savePlayer(actor);
      ws.send(JSON.stringify({type:'orders',data:getPlayerOrders(playerId)}));
      ws.send(JSON.stringify({type:'portfolio',data:snapshotPortfolio(actor)}));
    }

    // ── Cancel Limit Order ───────────────────────────────────────────────────
    if(msg.type==='cancel_limit'){
      const{orderId}=msg;
      const orders=getPlayerOrders(playerId);
      const idx=orders.findIndex(o=>o.id===orderId);
      if(idx>=0){
        const o=orders[idx];
        if(o.side==='buy' && o.reservedCash>0) safeAddCash(actor, o.reservedCash);
        orders.splice(idx,1);
        savePlayer(actor);
        ws.send(JSON.stringify({type:'orders',data:orders}));
        ws.send(JSON.stringify({type:'portfolio',data:snapshotPortfolio(actor)}));
      }
    }

    // ── Set / Buy Title ──────────────────────────────────────────────────────
    if (msg.type === 'set_title') {
      const { title } = msg;
      const titleStr = String(title || '').trim().slice(0, 80);
      const ownedTitles = actor.ownedTitles || [];
      // Tier-gated Patreon/CEO titles are unlocked by tier, not ownedTitles
      const TIER_GATED = {
        'Marked Subscriber':1,'Premium Wage Slave':1,
        'Officer of the Guild':2,'Merchant of the 7th Ward':2,
        'Corporate Apex Predator':3,'Sovereign of the Ledger':3,
      };
      const reqTier = TIER_GATED[titleStr];
      const playerTier = actor.patreon_tier || 0;
      const devAdmin = isDevAccount(actor.id) || isAdminAccount(actor.id);
      const tierOk = reqTier !== undefined && (devAdmin || playerTier >= reqTier);
      if (!titleStr || (!ownedTitles.includes(titleStr) && !tierOk)) {
        ws.send(JSON.stringify({ type: 'error', data: { msg: 'Title not owned.' } }));
        return;
      }
      actor.title = titleStr;
      savePlayer(actor);
      ws.send(JSON.stringify({ type: 'title_updated', data: { title: actor.title } }));
    }

    if (msg.type === 'unequip_title') {
      actor.title = '';
      savePlayer(actor);
      ws.send(JSON.stringify({ type: 'title_updated', data: { title: '' } }));
    }

    if (msg.type === 'buy_title') {
      const { title, price } = msg;
      const titleStr = String(title || '').trim().slice(0, 80);
      const cost = Math.max(0, Number(price) || 0);
      if (!titleStr || !cost) return;
      actor.ownedTitles = actor.ownedTitles || [];
      if (actor.ownedTitles.includes(titleStr)) {
        // Already owned — just equip
        actor.title = titleStr;
        savePlayer(actor);
        ws.send(JSON.stringify({ type: 'title_updated', data: { title: actor.title, owned: actor.ownedTitles } }));
        return;
      }
      if (actor.cash < cost) {
        ws.send(JSON.stringify({ type: 'error', data: { msg: `Insufficient funds. Need Ƒ${cost.toLocaleString()}.` } }));
        return;
      }
      safeAddCash(actor, -cost);
      actor.ownedTitles.push(titleStr);
      actor.title = titleStr;
      savePlayer(actor);
      ws.send(JSON.stringify({ type: 'title_updated', data: { title: actor.title, owned: actor.ownedTitles } }));
      ws.send(JSON.stringify({ type: 'portfolio', data: snapshotPortfolio(actor) }));
    }

    if (msg.type === 'get_titles') {
      actor.ownedTitles = actor.ownedTitles || [];
      ws.send(JSON.stringify({ type: 'title_state', data: { title: actor.title || '', owned: actor.ownedTitles } }));
    }


    if(msg.type==='ipo_apply'){
      const{symbol,qty}=msg;
      const s=String(symbol||'').toUpperCase();
      if(!activeIPO || activeIPO.symbol!==s || activeIPO.deadline<Date.now()){
        ws.send(JSON.stringify({type:'error',data:{msg:'IPO not active.'}}));
        return;
      }
      if(activeIPO.applied.has(playerId)){
        ws.send(JSON.stringify({type:'error',data:{msg:'Already participated in this IPO.'}}));
        return;
      }
      const maxShares=100;
      const q=Math.max(1,Math.min(Number(qty)||1,maxShares));
      const cost=activeIPO.discountPrice*q;
      if(actor.cash<cost){
        ws.send(JSON.stringify({type:'error',data:{msg:'Insufficient cash for IPO.'}}));
        return;
      }
      safeAddCash(actor,-cost);
      actor.holdings=actor.holdings||{};
      actor.holdings[s]=(actor.holdings[s]||0)+q;
      actor.basisC=actor.basisC||{};
      actor.basisC[s]=(actor.basisC[s]||0)+toCents(activeIPO.discountPrice)*q;
      actor.xp += 15;
      actor.level=calcLevel(actor.xp);
      activeIPO.applied.add(playerId);
      savePlayer(actor);
      broadcastTradeFeed({side:'buy',symbol:s,qty:q,price:activeIPO.discountPrice,isIPO:true});
      ws.send(JSON.stringify({type:'chat_system',data:{text:`IPO: Acquired ${q}× ${s} @ Ƒ${activeIPO.discountPrice.toFixed(2)} (${(((activeIPO.marketPrice-activeIPO.discountPrice)/activeIPO.marketPrice)*100).toFixed(1)}% discount)`}}));
      ws.send(JSON.stringify({type:'portfolio',data:snapshotPortfolio(actor)}));
      broadcastLeaderboard();
    }

    // ── Casino sync ──────────────────────────────────────────────────────────
    if(msg.type==='casino'){
      if(typeof msg.sync==='number'&&Number.isFinite(msg.sync)){
        // Sanity check: casino can only reduce or slightly increase cash (max +5000 per sync)
        const maxAllowed = actor.cash + 5000;
        const newCash = Math.max(0, Math.min(maxAllowed, msg.sync));
        actor.cash = Math.round(newCash * 100) / 100;
        savePlayer(actor);
        try {
          const equity = Object.entries(actor.holdings||{}).reduce((acc,[sym,qty])=>{
            const co=companies.find(x=>x.symbol===sym); return acc+(co?co.price*qty:0);
          },0);
          recordNetWorth(actor.id, actor.cash+equity, actor.cash, equity);
        } catch(_) {}
        ws.send(JSON.stringify({type:'portfolio',data:snapshotPortfolio(actor)}));
        ws.send(JSON.stringify({type:'me',data:{id:actor.id,name:actor.name,cash:actor.cash}}));
      }
    }

    // ── Transfer ─────────────────────────────────────────────────────────────
    if(msg.type==='transfer'){
      const{toName,amount}=msg;
      const amt=Math.max(1,Math.floor(Number(amount)||0));
      if(!toName||!amt)return;
      const fee = tier?.transferFee ? Math.ceil(amt*TAX_RATE) : 0;
      const total=amt+fee;
      if(actor.cash<total)return;
      const recipient=getPlayerByName(toName);
      if(!recipient)return ws.send(JSON.stringify({type:'error',data:{msg:`Player "${toName}" not found.`}}));
      actor.cash-=total; recipient.cash+=amt; actor.xp+=2;
      actor.level=calcLevel(actor.xp);
      savePlayer(actor); savePlayer(recipient);
      ws.send(JSON.stringify({type:'portfolio',data:snapshotPortfolio(actor)}));
      broadcastLeaderboard();
      const feeNote=fee>0?` (Ƒ${fee} tax sink)`:'  (no fee — CEO tier)';
      pushHeadline(`${actor.name} wired Ƒ${amt} to ${recipient.name}${feeNote}`,'neutral');
    }

    // ── Chart ────────────────────────────────────────────────────────────────
    if(msg.type==='chart'){const s=String(msg.symbol||'').toUpperCase(),c=companies.find(x=>x.symbol===s);if(c)ws.send(JSON.stringify({type:'chart',data:{symbol:s,ohlc:c.ohlc.slice(-200)}}));}

    // ── Request state ─────────────────────────────────────────────────────────
    if(msg.type==='request_state'){
      ws.send(JSON.stringify({type:'portfolio',data:snapshotPortfolio(actor)}));
      ws.send(JSON.stringify({type:'leaderboard',data:getLeaderboard(companies)}));
      ws.send(JSON.stringify({type:'orders',data:getPlayerOrders(playerId)}));
    }

    // ── Admin Commands (WebSocket) ────────────────────────────────────────────
    if(msg.type==='admin_cmd'){
      if(!isAdminAccount(playerId)){
        ws.send(JSON.stringify({type:'error',data:{msg:'Admin only.'}}));
        return;
      }
      const {cmd, targetName, minutes, reason, text: bcastText} = msg;

      if(cmd==='mute'){
        const target=getPlayerByName(String(targetName||'').trim());
        if(!target){ws.send(JSON.stringify({type:'error',data:{msg:'Player not found.'}}));return;}
        const mins=Math.max(1,Number(minutes)||10);
        const until=Date.now()+mins*60_000;
        setMute(target.id,until,actor.name,reason||'');
        broadcastToPlayer(target.id,{type:'system_message',data:{text:`You have been muted for ${mins} minute(s). Reason: ${reason||'none'}`,color:'#ff6b6b'}});
        ws.send(JSON.stringify({type:'admin_ack',data:{msg:`Muted ${target.name} for ${mins}m.`}}));
        broadcastToAdmins({type:'admin_log',data:{action:'mute',by:actor.name,target:target.name,minutes:mins,reason:reason||''}});
      }
      else if(cmd==='unmute'){
        const target=getPlayerByName(String(targetName||'').trim());
        if(!target){ws.send(JSON.stringify({type:'error',data:{msg:'Player not found.'}}));return;}
        clearMute(target.id);
        broadcastToPlayer(target.id,{type:'system_message',data:{text:'Your mute has been lifted.',color:'#51cf66'}});
        ws.send(JSON.stringify({type:'admin_ack',data:{msg:`Unmuted ${target.name}.`}}));
      }
      else if(cmd==='timeout'){
        const target=getPlayerByName(String(targetName||'').trim());
        if(!target){ws.send(JSON.stringify({type:'error',data:{msg:'Player not found.'}}));return;}
        const sockets=playerSockets.get(target.id);
        if(sockets&&sockets.size>0){
          const kickMsg=JSON.stringify({type:'kicked',data:{reason:reason||'Timed out by admin.'}});
          for(const s of sockets){try{s.send(kickMsg);s.terminate();}catch(_){}}
        }
        ws.send(JSON.stringify({type:'admin_ack',data:{msg:`Timed out ${target.name}.`}}));
        broadcastToAdmins({type:'admin_log',data:{action:'timeout',by:actor.name,target:target.name,reason:reason||''}});
      }
      else if(cmd==='broadcast'){
        if(!bcastText){ws.send(JSON.stringify({type:'error',data:{msg:'No text provided.'}}));return;}
        broadcast({type:'admin_broadcast',data:{text:String(bcastText).slice(0,500),from:actor.name,t:Date.now()}});
        ws.send(JSON.stringify({type:'admin_ack',data:{msg:'Broadcast sent.'}}));
      }
      else if(cmd==='online'){
        const online=[];
        for(const[pid]of playerSockets){const p=getPlayer(pid);if(p)online.push({name:p.name,level:p.level});}
        ws.send(JSON.stringify({type:'admin_online',data:{players:online,count:online.length}}));
      }
      return;
    }

    // ── God Mode (DEV only) ───────────────────────────────────────────────────
    if (msg.type === 'god_cmd') {
      if (!isDevAccount(playerId)) {
        ws.send(JSON.stringify({ type: 'error', data: { msg: 'Dev only.' } }));
        return;
      }
      const { cmd } = msg;
      const ack = (text, color) => ws.send(JSON.stringify({ type: 'god_ack', data: { msg: text, color: color || '#86ff6a' } }));
      const err = (text) => ws.send(JSON.stringify({ type: 'god_ack', data: { msg: '✗ ' + text, color: '#ff6b6b' } }));

      // ── give_cash: add/remove cash from a player ──────────────────────────
      if (cmd === 'give_cash') {
        const target = getPlayerByName(String(msg.targetName || '').trim());
        if (!target) return err('Player not found.');
        const amount = Number(msg.amount);
        if (!isFinite(amount)) return err('Invalid amount.');
        target.cash = Math.max(0, (target.cash || 0) + amount);
        savePlayer(target);
        broadcastToPlayer(target.id, { type: 'god_cash_update', data: { cash: target.cash, delta: amount, by: actor.name } });
        broadcastToAdmins({ type: 'admin_log', data: { action: 'god_give_cash', by: actor.name, target: target.name, amount } });
        ack(`✓ ${amount >= 0 ? 'Gave' : 'Removed'} $${Math.abs(amount).toLocaleString()} ${amount >= 0 ? 'to' : 'from'} ${target.name}. New balance: $${target.cash.toLocaleString(undefined,{maximumFractionDigits:2})}`);
      }

      // ── set_cash: set exact cash for a player ─────────────────────────────
      else if (cmd === 'set_cash') {
        const target = getPlayerByName(String(msg.targetName || '').trim());
        if (!target) return err('Player not found.');
        const amount = Number(msg.amount);
        if (!isFinite(amount) || amount < 0) return err('Invalid amount.');
        target.cash = amount;
        savePlayer(target);
        broadcastToPlayer(target.id, { type: 'god_cash_update', data: { cash: target.cash, delta: null, by: actor.name } });
        ack(`✓ Set ${target.name}'s cash to $${amount.toLocaleString(undefined,{maximumFractionDigits:2})}`);
      }

      // ── set_price: override a ticker price ────────────────────────────────
      else if (cmd === 'set_price') {
        const sym = String(msg.symbol || '').toUpperCase();
        const c = companies.find(x => x.symbol === sym);
        if (!c) return err(`Ticker ${sym} not found.`);
        const price = Number(msg.price);
        if (!isFinite(price) || price <= 0) return err('Price must be a positive number.');
        c.price = price;
        c.lnP = Math.log(price);
        broadcastToAdmins({ type: 'admin_log', data: { action: 'god_set_price', by: actor.name, symbol: sym, price } });
        ack(`✓ ${sym} price set to $${price.toFixed(2)}`);
      }

      // ── market_event: pump or crash all tickers ───────────────────────────
      else if (cmd === 'market_event') {
        const direction = String(msg.direction || '').toLowerCase();
        const pct = Math.min(0.5, Math.max(0.001, Number(msg.pct) / 100 || 0.05));
        if (direction !== 'pump' && direction !== 'crash') return err('direction must be pump or crash.');
        const sign = direction === 'pump' ? 1 : -1;
        for (const c of companies) {
          if (c._special) continue;
          c.lnP += sign * (pct * (0.5 + Math.random()));
          c.price = Math.max(0.5, Math.exp(c.lnP));
        }
        const label = direction === 'pump' ? '📈 MARKET SURGE' : '📉 MARKET CRASH';
        pushHeadline(`[GOD EVENT] ${label} — all tickers affected (${(pct*100).toFixed(1)}%)`, direction === 'pump' ? 'good' : 'bad', null);
        broadcastToAdmins({ type: 'admin_log', data: { action: 'god_market_event', by: actor.name, direction, pct } });
        ack(`✓ Market ${direction} applied (${(pct*100).toFixed(1)}%)`);
      }

      // ── inject_news: push a custom news headline ──────────────────────────
      else if (cmd === 'inject_news') {
        const text = String(msg.text || '').trim().slice(0, 300);
        if (!text) return err('News text required.');
        const tone = ['good', 'bad', 'neutral'].includes(msg.tone) ? msg.tone : 'neutral';
        const sym = msg.symbol ? String(msg.symbol).toUpperCase() : null;
        const c = sym ? companies.find(x => x.symbol === sym) : null;
        if (sym && !c) return err(`Ticker ${sym} not found.`);
        // Apply price effect if symbol specified
        if (c && tone === 'good')    { c.lnP += 0.02 + Math.random() * 0.04; c.price = Math.max(0.5, Math.exp(c.lnP)); }
        else if (c && tone === 'bad'){ c.lnP -= 0.02 + Math.random() * 0.04; c.price = Math.max(0.5, Math.exp(c.lnP)); }
        pushHeadline(text, tone, sym || undefined);
        broadcastToAdmins({ type: 'admin_log', data: { action: 'god_inject_news', by: actor.name, text, tone, symbol: sym } });
        ack(`✓ News injected: "${text.slice(0, 60)}${text.length > 60 ? '…' : ''}"`);
      }

      // ── set_patreon: assign a patreon tier to a player ────────────────────
      else if (cmd === 'set_patreon') {
        const target = getPlayerByName(String(msg.targetName || '').trim());
        if (!target) return err('Player not found.');
        const tier = Number(msg.tier);
        if (![0, 1, 2, 3].includes(tier)) return err('Tier must be 0, 1, 2, or 3.');
        if (tier === 3) {
          const ceos = countCEOs();
          if (ceos >= CEO_MAX && (target.patreon_tier || 0) < 3) return err(`CEO tier full (max ${CEO_MAX}).`);
        }
        const expiresAt = tier > 0 ? Date.now() + 365 * 24 * 60 * 60 * 1000 : null;
        setPatreonTier(target.id, tier, target.patreon_member_id || `dev_grant_${target.id}`, expiresAt);
        const tierNames = { 0: 'Free', 1: 'Premium ★', 2: 'Merchants Guild ⚖', 3: 'CEO ♛' };
        broadcastToPlayer(target.id, { type: 'patreon', data: { tier, tierName: tierNames[tier], message: tier > 0 ? `Patreon tier granted: ${tierNames[tier]}!` : 'Patreon tier removed.' } });
        broadcastToAdmins({ type: 'admin_log', data: { action: 'god_set_patreon', by: actor.name, target: target.name, tier } });
        ack(`✓ Set ${target.name}'s Patreon tier to ${tierNames[tier]}`);
      }

      // ── set_xp: set a player's XP ─────────────────────────────────────────
      else if (cmd === 'set_xp') {
        const target = getPlayerByName(String(msg.targetName || '').trim());
        if (!target) return err('Player not found.');
        const xp = Math.max(0, Number(msg.xp) || 0);
        target.xp = xp;
        savePlayer(target);
        broadcastToPlayer(target.id, { type: 'xp_update', data: { xp: target.xp } });
        ack(`✓ Set ${target.name}'s XP to ${xp.toLocaleString()}`);
      }

      // ── give_holdings: add/set shares for a player ────────────────────────
      else if (cmd === 'give_holdings') {
        const target = getPlayerByName(String(msg.targetName || '').trim());
        if (!target) return err('Player not found.');
        const sym = String(msg.symbol || '').toUpperCase();
        const c = companies.find(x => x.symbol === sym);
        if (!c) return err(`Ticker ${sym} not found.`);
        const qty = Math.round(Number(msg.qty) || 0);
        if (!isFinite(qty)) return err('Invalid quantity.');
        if (!target.holdings) target.holdings = {};
        const prev = target.holdings[sym] || 0;
        const newQty = Math.max(0, prev + qty);
        target.holdings[sym] = newQty;
        if (newQty === 0) delete target.holdings[sym];
        savePlayer(target);
        ack(`✓ ${target.name} ${sym}: ${prev} → ${newQty} shares (${qty >= 0 ? '+' : ''}${qty})`);
      }

      // ── reset_player: wipe a player's holdings/cash back to defaults ──────
      else if (cmd === 'reset_player') {
        const target = getPlayerByName(String(msg.targetName || '').trim());
        if (!target) return err('Player not found.');
        target.cash = 1000;
        target.holdings = {};
        target.xp = 0;
        target.level = 1;
        savePlayer(target);
        broadcastToPlayer(target.id, { type: 'system_message', data: { text: '⚠ Your account has been reset by a Game Master.', color: '#ff6b6b' } });
        broadcastToAdmins({ type: 'admin_log', data: { action: 'god_reset_player', by: actor.name, target: target.name } });
        ack(`✓ Reset ${target.name}'s account (cash $1000, no holdings)`);
      }

      // ── player_info: return full info about a player ──────────────────────
      else if (cmd === 'player_info') {
        const target = getPlayerByName(String(msg.targetName || '').trim());
        if (!target) return err('Player not found.');
        const equity = Object.entries(target.holdings || {}).reduce((acc, [sym, qty]) => {
          const co = companies.find(x => x.symbol === sym);
          return acc + (co ? co.price * qty : 0);
        }, 0);
        const online = playerSockets.has(target.id) && playerSockets.get(target.id).size > 0;
        ws.send(JSON.stringify({
          type: 'god_player_info',
          data: {
            id: target.id, name: target.name, cash: target.cash,
            holdings: target.holdings || {}, xp: target.xp, level: target.level,
            patreon_tier: target.patreon_tier || 0, is_dev: !!(isDevAccount(target.id)),
            is_admin: !!(isAdminAccount(target.id)), is_prime: !!(isOwnerAccount(target.id)),
            net_worth: target.cash + equity,
            equity, online,
          }
        }));
      }

      // ── list_players: return paginated list of all players ────────────────
      else if (cmd === 'list_players') {
        const lb = getLeaderboard(companies).slice(0, 100);
        ws.send(JSON.stringify({ type: 'god_player_list', data: { players: lb } }));
      }

      // ── god_broadcast: styled broadcast with GOD badge ────────────────────
      else if (cmd === 'god_broadcast') {
        const text = String(msg.text || '').trim().slice(0, 500);
        if (!text) return err('Text required.');
        broadcast({ type: 'admin_broadcast', data: { text, from: `⚡ ${actor.name}`, t: Date.now(), is_god: true } });
        ack(`✓ God broadcast sent.`);
      }

      // ── dunce: throw a player into the dunce corner ───────────────────────
      else if (cmd === 'dunce') {
        const target = getPlayerByName(String(msg.targetName || '').trim());
        if (!target) return err('Player not found.');
        // Only protect the duncing dev themselves — everyone else is fair game
        if (target.id === actor.id) return err('Cannot dunce yourself.');
        const reason = String(msg.reason || '').trim().slice(0, 200) || 'Unruly behaviour';
        setDunce(target.id, actor.name, reason);
        broadcastToPlayer(target.id, { type: 'dunced', data: { by: actor.name, reason } });
        broadcastToAdmins({ type: 'admin_log', data: { action: 'dunce_applied', by: actor.name, target: target.name, reason } });
        ack(`🎓 ${target.name} dunced. Reason: ${reason}`);
      }

      // ── undunce: remove a player from the dunce corner ────────────────────
      else if (cmd === 'undunce') {
        const target = getPlayerByName(String(msg.targetName || '').trim());
        if (!target) return err('Player not found.');
        clearDunce(target.id);
        broadcastToPlayer(target.id, { type: 'undunced', data: { msg: 'A dev has removed your dunce status.' } });
        broadcastToAdmins({ type: 'admin_log', data: { action: 'undunce', by: actor.name, target: target.name } });
        ack(`✓ ${target.name} un-dunced.`);
      }

      else {
        err(`Unknown god_cmd: ${cmd}`);
      }

      return;
    }

    // ── Chat ─────────────────────────────────────────────────────────────────
    if(msg.type==='chat'){
      const rawText=String(msg.text||'').slice(0,240); if(!rawText)return;

      // Dunce check — dunced players can only post in the dunce channel
      if(isDunced(playerId)){
        const channel = String(msg.channel||'global').toLowerCase();
        if(channel !== 'dunce'){
          ws.send(JSON.stringify({type:'error',data:{msg:`🎓 You are in the dunce corner. You can only chat in the Dunce channel.`}}));
          return;
        }
        // Route dunce message: send to dunced player + all devs/admins
        const duncePayload = { type:'chat', data:{id:uuidv4(),t:Date.now(),user:actor.name,text:rawText,
          badge:'🎓',color:'#ff4444',channel:'dunce',title:actor.title||null,is_dunced:true}};
        wss.clients.forEach(c=>{
          if(c.readyState!==1) return;
          const cId = wsPlayers.get(c);
          if(!cId) return;
          if(isDunced(cId) || isDevAccount(cId) || isAdminAccount(cId)) c.send(JSON.stringify(duncePayload));
        });
        return;
      }

      // Mute check
      if(isMuted(playerId)){
        const expiry = getMuteExpiry(playerId);
        const minsLeft = Math.ceil((expiry - Date.now()) / 60_000);
        ws.send(JSON.stringify({type:'error',data:{msg:`You are muted for ${minsLeft} more minute(s).`}}));
        return;
      }

      // Slur filter
      const { clean: text, flagged } = filterChat(rawText);
      if (flagged) {
        // Silently replace for everyone; log for admins
        broadcastToAdmins({ type: 'admin_log', data: {
          action: 'slur_filtered', user: actor.name, original: rawText
        }});
      }

      const channel = String(msg.channel||'global').toLowerCase();
      // Gate special channels
      if(channel==='patreon' && (!actor.patreon_tier || actor.patreon_tier<1)) return;
      if(channel==='guild'   && !isGuildEligible(actor)) return;
      const _isOwner = isOwnerAccount(actor.id);
      const _isDev   = !_isOwner && !!(isDevAccount(actor.id)||isAdminAccount(actor.id));
      const chatBadge = _isOwner ? '★' : (_isDev ? null : (tier?.badge||null));
      const chatColor = _isOwner ? '#ff6a00' : (_isDev ? null : (tier?.chatColor||null));
      const payload={type:'chat',data:{id:uuidv4(),t:Date.now(),user:actor.name,text,badge:chatBadge,color:chatColor,channel,title:actor.title||null,is_dev:_isDev,is_prime:_isOwner}};
      if(channel==='global'){
        broadcast(payload);
      } else {
        // Only send to qualifying players
        wss.clients.forEach(c=>{
          if(c.readyState!==1) return;
          const cPlayerId = wsPlayers.get(c);
          const cPlayer = cPlayerId ? getPlayer(cPlayerId) : null;
          if(!cPlayer) return;
          if(channel==='patreon' && (cPlayer.patreon_tier||0)<1) return;
          if(channel==='guild'   && !isGuildEligible(cPlayer)) return;
          c.send(JSON.stringify(payload));
        });
      }
    }


    // -- Whisper / private message
    if(msg.type==='whisper'){
      const rawText=String(msg.text||'').slice(0,240); if(!rawText)return;
      const targetName=String(msg.to||'').trim();
      if(!targetName){ws.send(JSON.stringify({type:'error',data:{msg:'Specify a recipient: @name message'}}));return;}
      if(isDunced(playerId)){ws.send(JSON.stringify({type:'error',data:{msg:'Dunced players cannot whisper.'}}));return;}
      if(isMuted(playerId)){ws.send(JSON.stringify({type:'error',data:{msg:'You are muted and cannot whisper.'}}));return;}
      const target=getPlayerByName(targetName);
      if(!target){ws.send(JSON.stringify({type:'error',data:{msg:`Player "${targetName}" not found.`}}));return;}
      if(target.id===actor.id){ws.send(JSON.stringify({type:'error',data:{msg:"You can't whisper to yourself."}}));return;}
      const {clean:wText}=filterChat(rawText);
      const _isOwner=isOwnerAccount(actor.id);
      const _isDev=!_isOwner&&!!(isDevAccount(actor.id)||isAdminAccount(actor.id));
      const wBadge=_isOwner?'★':(_isDev?null:(TIERS[actor.patreon_tier||0]?.badge||null));
      const wColor=_isOwner?'#ff6a00':(_isDev?null:(TIERS[actor.patreon_tier||0]?.chatColor||null));
      const base={id:uuidv4(),t:Date.now(),from:actor.name,to:target.name,text:wText,badge:wBadge,color:wColor,is_prime:_isOwner,is_dev:_isDev};
      broadcastToPlayer(target.id,{type:'whisper',data:{...base,sent:false}});
      ws.send(JSON.stringify({type:'whisper',data:{...base,sent:true}}));
    }

    // ── Fund request ─────────────────────────────────────────────────────────
    if(msg.type==='fund_request'){
      if(isGuildEligible(actor)){
        const snap = fundSnapshot();
        snap.isMember   = isFundMember(actor.id);
        snap.myShares   = getFundMember(actor.id)?.shares || 0;
        snap.myValue    = snap.myShares * snap.pricePerShare;
        snap.canPropose = true;
        snap.myVotes    = actor.patreon_tier >= 3 ? 2 : 1;
        ws.send(JSON.stringify({type:'fund_update', data:snap}));
      }
    }
  });

  ws.on('close',()=>{
    const playerId=wsPlayers.get(ws);
    if(playerId&&playerSockets.has(playerId)){playerSockets.get(playerId).delete(ws);if(playerSockets.get(playerId).size===0)playerSockets.delete(playerId);}
    broadcastLeaderboard();
  });
});

// ─── Timers ───────────────────────────────────────────────────────────────────

setInterval(stepMarket, TICK_MS);
setInterval(broadcastLeaderboard, 15000);
setInterval(genHeadline, NEWS_MS);
setInterval(() => { try { saveMarketState(companies, headlines); } catch(e) {} }, 60_000);
setInterval(() => { try { processFundProposals(); } catch(e) {} }, 60_000);

// Periodic net worth snapshot every 5 minutes for all online players
// (ensures P&L history tracks even if player isn't actively trading)
setInterval(() => {
  try {
    for (const [playerId, sockets] of playerSockets) {
      if (!sockets.size) continue;
      const p = getPlayer(playerId); if (!p) continue;
      const equity = Object.entries(p.holdings||{}).reduce((acc,[sym,qty])=>{
        const co = companies.find(x=>x.symbol===sym); return acc+(co?co.price*qty:0);
      },0);
      recordNetWorth(p.id, p.cash+equity, p.cash, equity);
    }
  } catch(e) {}
}, 5 * 60 * 1000);

// v5.0 timers
setInterval(() => { try { runEarningsEvent(); } catch(e) { console.error('[Earnings]', e); } }, EARNINGS_INTERVAL_MS);
setInterval(() => { try { runIPOEvent(); } catch(e) { console.error('[IPO]', e); } }, IPO_INTERVAL_MS);
setInterval(() => { try { runDividends(); } catch(e) { console.error('[Dividends]', e); } }, DIVIDEND_INTERVAL_MS);
setInterval(() => { try { runBorrowFees(); } catch(e) { console.error('[Borrow]', e); } }, BORROW_INTERVAL_MS);

// Reset prevClose at midnight
setInterval(() => {
  const now = new Date();
  if (now.getHours() === 0 && now.getMinutes() === 0) resetDailyPrevClose();
}, 60_000);

// Passive income every 30 minutes
setInterval(()=>{
  try{
    const result=creditPassiveIncome();
    const {count, payouts, guildMemberCount} = result;

    // ── Syndicate grey-market colony bonus (flat per controlled colony) ───────
    let colonyStates = [];
    let playerFactions = {};
    try { colonyStates = getAllColonyStates(); } catch(_) {}
    try { playerFactions = getPlayerFactionsBulk(); } catch(_) {}

    // Count Syndicate-controlled non-contested colonies for grey-market bonus
    const syndicateColonies = colonyStates.filter(c => {
      if (c.id === 'flesh_station') return false;
      const ctrl = {coalition:c.control_coalition||0,syndicate:c.control_syndicate||0,void:c.control_void||0};
      const leading = ['coalition','syndicate','void'].reduce((b,f)=>ctrl[f]>ctrl[b]?f:b,'coalition');
      return leading === 'syndicate';
    });
    const SYNDICATE_GREY_PER_COLONY = 750; // Ƒ per controlled colony per 30min

    if(count>0){
      console.log(`[Income] Credited passive income to ${count} players`);
      for(const payout of payouts){
        const p=getPlayer(payout.id); if(!p) continue;
        const sockets=playerSockets.get(payout.id)||new Set();

        // Syndicate grey-market bonus
        let synBonus = 0;
        if (playerFactions[payout.id] === 'syndicate' && syndicateColonies.length > 0) {
          synBonus = syndicateColonies.length * SYNDICATE_GREY_PER_COLONY;
          p.cash = Math.round((p.cash + synBonus) * 100) / 100;
          savePlayer(p);
        }

        // Record net worth for every player on income tick
        try {
          const equity = Object.entries(p.holdings||{}).reduce((acc,[sym,qty])=>{
            const co=companies.find(x=>x.symbol===sym); return acc+(co?co.price*qty:0);
          },0);
          recordNetWorth(p.id, p.cash+equity, p.cash, equity);
        } catch(_) {}

        if(sockets.size===0) continue;
        const portfolioMsg=JSON.stringify({type:'portfolio',data:snapshotPortfolio(p)});
        let incomeText;
        if (payout.isDev) {
          incomeText = `⚡ Dev passive: +Ƒ${payout.total.toLocaleString()} — FLSH Capital dividend`;
        } else if (synBonus > 0) {
          incomeText = `+Ƒ${payout.total} passive  ·  +Ƒ${synBonus} Syndicate grey-market (${syndicateColonies.length} colony)`;
        } else if (payout.bonus > 0) {
          incomeText = `+Ƒ${payout.base} passive income  ·  +Ƒ${payout.bonus} guild bonus`;
        } else {
          incomeText = `+Ƒ${payout.total} passive income`;
        }
        const totalWithBonus = payout.total + synBonus;
        const incomeMsg=JSON.stringify({type:'income',data:{base:payout.base,bonus:payout.bonus+synBonus,total:totalWithBonus,guildMemberCount,text:incomeText}});
        for(const ws of sockets){try{if(ws.readyState===1){ws.send(portfolioMsg);ws.send(incomeMsg);}}catch(e){}}
      }
      for(const[pid,sockets]of playerSockets){
        const p=getPlayer(pid); if(!p)continue;
        const msg=JSON.stringify({type:'portfolio',data:snapshotPortfolio(p)});
        for(const ws of sockets){try{if(ws.readyState===1)ws.send(msg);}catch(e){}}
      }
      broadcastLeaderboard();
    }
  }catch(e){console.error('[Income error]',e);}
}, INCOME_INTERVAL_MS);

// Check for expired Patreon memberships hourly
setInterval(()=>{
  try{const n=revokeExpiredPatreon();if(n>0)console.log(`[Patreon] Revoked ${n} expired memberships`);}catch(e){}
}, 60*60*1000);

// Fund savings interest — hourly
setInterval(()=>{
  try {
    const total = applyFundSavingsInterest();
    if (total > 0) {
      console.log(`[Funds] Savings interest: Ƒ${total.toFixed(2)}`);
      for (const fund of getAllFunds()) {
        const snap = fundDetailSnapshot(fund.id, null);
        broadcastToFundMembers(fund.id, { type:'fund_update', data:{ fundId:fund.id, ...snap }});
      }
      updateFLSHPrice();
    }
  } catch(e) { console.error('[Funds savings error]', e); }
}, 60 * 60 * 1000);

// ─── Galaxy: Hourly tension tick + conquest resolution ────────────────────────
function runGalaxyTick() {
  try {
    const colonies = getAllColonyStates();
    const now = Date.now();
    for (const c of colonies) {
      const ctrl = { coalition: c.control_coalition, syndicate: c.control_syndicate, void: c.control_void };
      const leading = ['coalition','syndicate','void'].reduce((best, f) => ctrl[f] > ctrl[best] ? f : best, 'coalition');
      const contested = ctrl[leading] < 60 ? 1 : 0;

      // Check conquest timer
      if (c.conquest_timer && c.conquest_faction && now >= c.conquest_timer) {
        // Conquest resolves — colony changes hands
        const oldFaction = c.faction;
        const newFaction = c.conquest_faction;
        updateColonyState(c.id, {
          faction: newFaction,
          conquest_faction: null,
          conquest_timer: null,
          tension: Math.max(5, c.tension - 30),
          contested: 0,
        });
        // Fire conquest headline
        const COLONY_NAMES = {
          new_anchor:'New Anchor', cascade_station:'Cascade Station',
          frontier_outpost:'Frontier Outpost', the_hollow:'The Hollow',
          vein_cluster:'Vein Cluster', aurora_prime:'Aurora Prime', null_point:'Null Point',
          flesh_station:'Flesh Station',
        };
        const FACTION_NAMES = { coalition:'Coalition', syndicate:'Syndicate', void:'Void Collective', fleshstation:'Flesh Station' };
        const cName = COLONY_NAMES[c.id] || c.id;
        const fName = FACTION_NAMES[newFaction] || newFaction;
        const oldName = FACTION_NAMES[oldFaction] || oldFaction;
        const headline = `${fName} seizes ${cName} from ${oldName} — power shifts in the outer sectors`;
        pushHeadline(headline, 'bad', '⚠');
        broadcast({ type:'colony_conquered', data:{
          colonyId: c.id, colonyName: cName, newFaction, oldFaction, warChest: c.war_chest
        }});
        console.log(`[Galaxy] Conquest: ${newFaction} takes ${c.id} from ${oldFaction}`);
        continue;
      }

      // Natural tension drift (contested colonies gain tension, others decay)
      let newTension = c.tension;
      if (contested) newTension = Math.min(90, newTension + 2);
      else newTension = Math.max(0, newTension - 1);

      if (newTension !== c.tension || contested !== c.contested) {
        updateColonyState(c.id, { tension: newTension, contested });
        broadcast({ type:'colony_update', data:{
          colonyId: c.id, tension: newTension, contested,
          control_coalition: c.control_coalition,
          control_syndicate: c.control_syndicate,
          control_void: c.control_void,
          conquest_faction: c.conquest_faction || null,
          conquest_timer: c.conquest_timer || null,
        }});
      }
    }
  } catch(e) { console.error('[Galaxy tick]', e); }
}
setInterval(runGalaxyTick, 60 * 60 * 1000); // hourly

for(const sig of['SIGINT','SIGTERM']){
  process.on(sig,()=>{console.log(`[${sig}] Saving...`);saveMarketState(companies,headlines);process.exit(0);});
}

// ─── Start server ─────────────────────────────────────────────────────────────

server.listen(PORT,()=>{
  console.log(`\n╔══════════════════════════════════════╗`);
  console.log(`║  Flesh Market v5.0  — port ${PORT}      ║`);
  console.log(`╚══════════════════════════════════════╝`);
  console.log(`   Companies: ${companies.length}`);
  console.log(`   Features: Limit Orders, Short Selling, Earnings, IPOs, Dividends, Trade Feed, XP/Levels`);
  console.log(`   DB: ${process.env.DB_PATH||'fleshmarket.db'}`);
  if (DEV_ACCOUNTS.length) {
    syncDevAccounts(DEV_ACCOUNTS);
    console.log(`   Dev accounts: ${DEV_ACCOUNTS.join(', ')}`);
  }
  console.log('');
});
